import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import test from 'node:test';
import {createTemporaryDirectory} from '../helpers/cleanup.mjs';
import {upsertStatisticsRole} from '../../lib/reviewer-benchmark/statistics-storage.mjs';

/** @param {string} model @param {string} reviewerId @param {{backend:string,serviceTier:string}|undefined} conditions @returns {import('../../lib/reviewer-benchmark/statistics.mjs').Statistics} */
const role = (model,reviewerId,conditions) => ({schemaVersion:4,configuration:{model,reasoningEffort:'explicit-effort'},
    roles:[{reviewerId,repetitions:[1,2,3].map(repetition => ({repetition,score:0.25,scoreSource:'formal',diagnosticReason:null,
        mainAgentCorrectedScoringCopy:false,completedInstances:1,expectedInstances:1,deliveryErrors:[]}))}],
    observations:[1,2,3].map(repetition => ({reviewerId,scenarioId:'default',repetition,completed:true,
        delivery:{mode:'reviewer-bound-report',errors:[],mainAgentCorrectedScoringCopy:false},
        runtime:{actualModel:model,actualReasoningEffort:'explicit-effort',durationMs:repetition,
            tokenUsage:{input:11,cachedInput:3,output:7},conditions:conditions ?? {}}}))});

test('role insertion preserves legacy values and rejects score and provider/tier conflicts without writes',async t => {
    const directory = await createTemporaryDirectory(t,'arw-benchmark-storage-');
    const legacy = [role('legacy-model','code-standards-reviewer',undefined)];
    const entry = role('new-explicit-model','code-standards-reviewer',{backend:'provider-a',serviceTier:'default'});
    await writeFile(join(directory,'statistics.json'),JSON.stringify(legacy));
    const first = await upsertStatisticsRole({outputDirectory:directory,roleStatistics:entry});
    assert.equal(first.inserted,true);
    const saved = JSON.parse(await readFile(first.path,'utf8'));
    assert.deepEqual(saved,[...legacy,entry]);
    const bytes = await readFile(first.path);
    assert.equal((await upsertStatisticsRole({outputDirectory:directory,roleStatistics:entry})).inserted,false);
    assert.deepEqual(await readFile(first.path),bytes);
    const changedScore = structuredClone(entry);changedScore.roles[0].repetitions[0].score = 0.75;
    await assert.rejects(upsertStatisticsRole({outputDirectory:directory,roleStatistics:changedScore}),/differ/u);
    for (const conditions of [{backend:'provider-b',serviceTier:'default'},{backend:'provider-a',serviceTier:'fast'}]) {
        const conflict = role('new-explicit-model','code-spec-reviewer',conditions);
        await assert.rejects(upsertStatisticsRole({outputDirectory:directory,roleStatistics:conflict}),/provider or service tier conditions differ/u);
        assert.deepEqual(await readFile(first.path),bytes);
    }
    const unknown = role('legacy-model','code-spec-reviewer',{backend:'provider-a',serviceTier:'default'});
    await assert.rejects(upsertStatisticsRole({outputDirectory:directory,roleStatistics:unknown}),/conditions differ/u);
    assert.deepEqual(await readFile(first.path),bytes);
});
