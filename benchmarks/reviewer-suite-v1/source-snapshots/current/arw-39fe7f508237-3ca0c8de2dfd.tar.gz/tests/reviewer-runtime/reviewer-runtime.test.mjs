import {initialStrataWorkState} from '../../lib/background-agent/strata-work-policy.mjs';
import {createModelTelemetryReceiver} from '../../lib/background-agent/model-telemetry.mjs';
import assert from 'node:assert/strict';
import test from 'node:test';
import {link, mkdir, readFile, rm, symlink, writeFile} from 'node:fs/promises';
import {join, relative} from 'node:path';
import {backgroundAgentRecoveryPath} from '../../lib/background-agent/recovery-record.mjs';
import {createReviewerRuntime} from '../../lib/reviewer-runtime/reviewer-runtime.mjs';
import {createUsage} from '../../lib/reviewer-runtime/reviewer-measurement.mjs';
import {readReviewerSessionRecord, saveReviewerSessionRecord} from '../../lib/reviewer-runtime/reviewer-session-record.mjs';
import {createTemporaryDirectory} from '../helpers/cleanup.mjs';
import {createReviewerRuntimeFixture, createScriptedReviewerSessions, reviewerHandoff} from '../helpers/reviewer-runtime-adapter.mjs';

/** @typedef {import('../../lib/reviewer-runtime/reviewer-runtime.mjs').ReviewerRuntimeResult} ReviewerRuntimeResult */
/** @param {ReviewerRuntimeResult} response */
const succeeded = response => {
    assert.equal(response.status, 'succeeded', response.status === 'failed' ? response.error.message : '');
    if (response.status !== 'succeeded') throw new Error('Expected successful Reviewer operation.');
    return response.result;
};
/** @param {ReviewerRuntimeResult} response @param {string} code */
const failed = (response, code) => {
    assert.equal(response.status, 'failed');
    if (response.status === 'failed') assert.equal(response.error.code, code);
};
const options = (/** @type {ReturnType<typeof createReviewerRuntimeFixture>} */ fixture) => ({
    nativeSessions: fixture.native.nativeSessions, filesystem: fixture.filesystem,
    clock: fixture.clock, recoveryBoundary: fixture.recoveryBoundary,
});
/** @param {ReturnType<typeof createReviewerRuntimeFixture>} fixture @param {{runId:string,recoveryPath:string}} observed @param {import('../../lib/background-agent/state-store.mjs').AgentState} state */
const managedBinding = async (fixture, observed, state) => {
    const opened = await fixture.filesystem.open({root: reviewerHandoff.cwd});
    assert.equal(opened.status, 'succeeded');
    if (opened.status !== 'succeeded') throw new Error('Scripted repository unavailable.');
    const path = relative(reviewerHandoff.cwd, observed.recoveryPath).split('\\').join('/');
    const record = await readReviewerSessionRecord(opened.scopedFilesystem, observed.recoveryPath, path);
    assert.ok(record);
    return /** @type {import('../../lib/background-agent/state-store.mjs').BackgroundAgentRow} */ (/** @type {unknown} */ ({
        runId: observed.runId, role: record.role, threadId: record.threadId, sessionPath: record.sessionPath,
        recoveryPath: backgroundAgentRecoveryPath({stateDirectory: reviewerHandoff.stateDirectory,runId: observed.runId}),
        cwd: record.cwd, readPaths: record.readPaths, writePaths: record.writePaths, settings: record.settings, state,
    }));
};
const start = async (/** @type {ReturnType<typeof createReviewerRuntimeFixture>} */ fixture, /** @type {typeof reviewerHandoff} */ handoff = reviewerHandoff) => {
    const runtime = createReviewerRuntime(options(fixture));
    const accepted = succeeded(await runtime.execute({operation: 'spawn_agent', input: handoff}));
    assert.equal(accepted.deliveryStatus, 'accepted');
    assert.equal(typeof accepted.messageId, 'string');
    assert.equal(accepted.threadId, null);
    const observed = succeeded(await runtime.inspect({runId: accepted.runId}));
    assert.equal(typeof observed.threadId, 'string');
    assert.equal(typeof observed.turnId, 'string');
    return {runtime, accepted, observed};
};

test('spawn accepts once before native work, then verifies a bound report and root-only usage', async () => {
    const fixture = createReviewerRuntimeFixture();
    const runtime = createReviewerRuntime(options(fixture));
    failed(await runtime.execute({operation: 'spawn_agent', input: {...reviewerHandoff, settings: {...reviewerHandoff.settings, serviceTier: null}}}), 'invalid-input');
    assert.equal(fixture.native.sessions.length, 0);
    const accepted = succeeded(await runtime.execute({operation: 'spawn_agent', input: reviewerHandoff}));
    assert.equal(accepted.threadId, null);
    assert.equal(accepted.turnId, null);
    assert.equal(accepted.deliveryStatus, 'accepted');
    assert.equal(fixture.native.calls.some(call => call.operation === 'startTurn'), false);
    const observed = succeeded(await runtime.inspect({runId: accepted.runId}));
    assert.equal(fixture.native.calls.filter(call => call.operation === 'startTurn').length, 1);
    assert.equal(fixture.native.calls.filter(call => call.operation === 'dispatchAccepted').length, 1);
    assert.equal(observed.state, 'running');
    assert.equal(observed.completion, null);
    failed(await runtime.execute({operation: 'spawn_agent', input: {...reviewerHandoff, newThread: true}}), 'reviewer-busy');
    assert.equal(fixture.native.calls.filter(call => call.operation === 'start').length, 1);
    assert.equal(fixture.native.sessions[0].input.settings.config['agents.enabled'], false);
    const root = fixture.native.members.get(/** @type {string} */ (observed.threadId));
    assert.ok(root);
    root.usage = createUsage(17);
    fixture.clock.advance(120);
    await fixture.writeReport('The complete Reviewer-written report.');
    fixture.native.finish(root.threadId);
    const completed = succeeded(await runtime.inspect({runId: accepted.runId}));
    assert.deepEqual(completed.completion, {status: 'ready', reportPath: reviewerHandoff.reportPath});
    assert.equal(completed.measurement?.usage.totalTokens, 17);
    assert.equal(completed.measurement?.wallClockMs, 120);
    assert.equal(JSON.stringify(completed).includes('The complete Reviewer-written report.'), false);
    failed(await runtime.execute({operation: 'spawn_agent', input: reviewerHandoff}), 'reviewer-identity-exists');
    await runtime.close();
});

test('a provisional missing report stays live, then a native completion retires it without another inspection', async () => {
    const fixture = createReviewerRuntimeFixture();
    /** @type {(runId:string)=>void} */ let resolveRetired = () => {};
    const retired = new Promise(resolve => {resolveRetired = resolve;});
    /** @type {string[]} */ const retiredRuns = [];
    const runtime = createReviewerRuntime({...options(fixture), onRetired: runId => {retiredRuns.push(runId);resolveRetired(runId);}});
    const accepted = succeeded(await runtime.execute({operation: 'spawn_agent',input: reviewerHandoff}));
    const active = succeeded(await runtime.inspect({runId: accepted.runId}));
    const threadId = /** @type {string} */ (active.threadId);
    fixture.native.finish(threadId);
    assert.equal(succeeded(await runtime.inspect({runId: accepted.runId})).completion?.status, 'incomplete');
    assert.equal(runtime.holdsRun(accepted.runId), true);
    assert.deepEqual(retiredRuns, []);
    await fixture.writeReport('Personally written final report.');
    fixture.native.emit(threadId);
    await retired;
    assert.deepEqual(retiredRuns, [accepted.runId]);
    assert.equal(runtime.holdsRun(accepted.runId), false);
    assert.equal(fixture.native.sessions[0].attached, false);
    const managed = await managedBinding(fixture, active, 'running');
    const cold = succeeded(await runtime.inspect({runId: accepted.runId,managed}));
    assert.equal(cold.completion?.status, 'ready');
    const nextReport = `${reviewerHandoff.writePaths[0]}/next-report.md`;
    await fixture.writeReport('', nextReport);
    const next = succeeded(await runtime.execute({operation: 'followup_task',input: {
        ...reviewerHandoff,runId: accepted.runId,reportPath: nextReport,handoff: 'Review another complete input.',
    }}));
    const resumed = succeeded(await runtime.inspect({runId: next.runId}));
    assert.equal(resumed.threadId, threadId);
    assert.equal(next.runId, accepted.runId);
    await runtime.close();
    {
    const continuingFixture=createReviewerRuntimeFixture();
    let work=initialStrataWorkState(false);let instructions=0;
    const nativeSessions={open:async(/** @type {Parameters<typeof continuingFixture.native.nativeSessions.open>[0]} */ input)=>{
        const session=await continuingFixture.native.nativeSessions.open(input);
        return Object.assign(session,{
            getProviderWork:()=>/** @type {Record<string,unknown>} */(/** @type {unknown} */(work)),
            saveProviderWork:/** @param {Record<string,unknown>} state */ state=>{work=/** @type {typeof work} */(/** @type {unknown} */(state));},
            configureReviewerTask:async()=>({enabled:true,settings:input.settings,compactBinding:null}),
            continueTask:async(/** @type {NonNullable<typeof session.continueTask> extends (input:infer T)=>unknown?T:never} */ request)=>{
                const root=continuingFixture.native.members.get(request.rootThreadId);assert.ok(root);assert.equal(root.turnId,request.endedTurnId);
                instructions++;request.onAccepted(`program-${instructions}`);
                const delivered=await session.startTurn({threadId:request.rootThreadId,handoff:request.instruction});
                return {turnId:/** @type {string} */(delivered.turnId),deliveryStatus:'delivered'};
            },
        });
    }};
    const continuing=createReviewerRuntime({...options(continuingFixture),nativeSessions});
    const receipt=succeeded(await continuing.execute({operation:'spawn_agent',input:reviewerHandoff}));
    const before=succeeded(await continuing.inspect({runId:receipt.runId}));
    const originalThread=/** @type {string} */(before.threadId);const root=continuingFixture.native.members.get(originalThread);assert.ok(root);
    root.usage=createUsage(20);continuingFixture.clock.advance(50);continuingFixture.native.finish(originalThread,'Progress only.');
    const resumed=succeeded(await continuing.inspect({runId:receipt.runId}));
    assert.equal(resumed.completion,null);assert.equal(resumed.threadId,originalThread);assert.equal(resumed.runId,receipt.runId);
    assert.notEqual(resumed.turnId,before.turnId);assert.equal(instructions,1);
    assert.equal(resumed.measurement?.usage.totalTokens,20);
    await continuing.execute({operation:'interrupt_agent',input:{runId:receipt.runId,turnId:resumed.turnId}});
    continuingFixture.native.emit(originalThread);await new Promise(resolve=>setImmediate(resolve));
    assert.equal(instructions,1);assert.ok(work.stopReason);await continuing.close();
    }

});

test('a queued follow-up reattaches after a coalesced completion retires its captured handle', async () => {
    const fixture = createReviewerRuntimeFixture();
    let pauseSnapshot = false;
    /** @type {()=>void} */ let captured = () => {};
    /** @type {()=>void} */ let release = () => {};
    const entered = new Promise(resolve => {captured = () => resolve(undefined);});
    const gate = new Promise(resolve => {release = () => resolve(undefined);});
    const nativeSessions = {
        async open(/** @type {Parameters<typeof fixture.native.nativeSessions.open>[0]} */ input) {
            const session = await fixture.native.nativeSessions.open(input);
            return Object.assign(Object.create(session), {
                async snapshot(/** @type {Parameters<typeof session.snapshot>[0]} */ request) {
                    const facts = await session.snapshot(request);
                    if (pauseSnapshot) {pauseSnapshot = false;captured();await gate;}
                    return facts;
                },
            });
        },
    };
    const runtime = createReviewerRuntime({...options(fixture),nativeSessions});
    const first = succeeded(await runtime.execute({operation: 'spawn_agent',input: reviewerHandoff}));
    const active = succeeded(await runtime.inspect({runId: first.runId}));
    const threadId = /** @type {string} */ (active.threadId);
    await fixture.writeReport('First complete report.');
    const nextReport = `${reviewerHandoff.writePaths[0]}/queued-followup.md`;
    await fixture.writeReport('', nextReport);
    pauseSnapshot = true;
    fixture.native.emit(threadId);
    await entered;
    const pending = runtime.execute({operation: 'followup_task',input: {
        ...reviewerHandoff,runId: first.runId,reportPath: nextReport,handoff: 'Review the next input.',
    }});
    await new Promise(resolve => setImmediate(resolve));
    fixture.native.finish(threadId);
    release();
    const accepted = succeeded(await pending);
    assert.equal(accepted.runId, first.runId);
    assert.equal(fixture.native.sessions.length, 2);
    const next = succeeded(await runtime.inspect({runId: first.runId}));
    assert.equal(next.threadId, threadId);
    assert.equal(next.state, 'running');
    assert.equal(fixture.native.sessions[0].attached, false);
    assert.equal(fixture.native.sessions[1].attached, true);
    await runtime.close();
});

test('a follow-up waits for the previous completed turn to finish terminal cleanup', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime, observed} = await start(fixture);
    const threadId = /** @type {string} */ (observed.threadId);
    /** @type {()=>void} */ let entered = () => {};
    /** @type {()=>void} */ let release = () => {};
    const cleanupEntered = new Promise(resolve => {entered = () => resolve(undefined);});
    const cleanupGate = new Promise(resolve => {release = () => resolve(undefined);});
    const root = fixture.native.members.get(threadId);
    assert.ok(root);
    const nativeRoot = /** @type {typeof root & {turnStatus?: 'inProgress' | 'completed'}} */ (root);
    nativeRoot.state = 'idle';
    nativeRoot.turnStatus = 'inProgress';
    fixture.native.backgroundTerminals.set(threadId, new Set(['old-turn-terminal']));
    assert.equal(succeeded(await runtime.inspect({runId: observed.runId})).state, 'running');
    assert.deepEqual([...fixture.native.backgroundTerminals.get(threadId) ?? []], ['old-turn-terminal']);
    fixture.native.afterCleanupBehaviors.set(threadId, async () => {entered(); await cleanupGate;});
    await fixture.writeReport('First complete report.');
    fixture.native.finish(threadId);
    nativeRoot.turnStatus = 'completed';
    await cleanupEntered;
    const nextReport = `${reviewerHandoff.writePaths[0]}/after-cleanup.md`;
    await fixture.writeReport('', nextReport);
    const pending = runtime.execute({operation: 'followup_task', input: {
        ...reviewerHandoff, runId: observed.runId, reportPath: nextReport,
        handoff: 'Review a new complete input.',
    }});
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(fixture.native.calls.filter(call => call.operation === 'startTurn').length, 1);
    release();
    const accepted = succeeded(await pending);
    assert.equal(accepted.runId, observed.runId);
    const resumed = succeeded(await runtime.inspect({runId: observed.runId}));
    assert.equal(resumed.threadId, threadId);
    assert.equal(resumed.state, 'running');
    fixture.native.backgroundTerminals.set(threadId, new Set(['new-turn-terminal']));
    assert.deepEqual([...fixture.native.backgroundTerminals.get(threadId) ?? []], ['new-turn-terminal']);
    await runtime.close();
});

test('completion observed before native start acknowledgment still finishes terminal cleanup', async () => {
    const fixture = createReviewerRuntimeFixture();
    const nativeSessions = {
        async open(/** @type {Parameters<typeof fixture.native.nativeSessions.open>[0]} */ input) {
            const session = await fixture.native.nativeSessions.open(input);
            return Object.assign(Object.create(session), {
                async dispatchAccepted(/** @type {Parameters<typeof session.dispatchAccepted>[0]} */ request) {
                    const delivered = await session.dispatchAccepted(request);
                    const rootThreadId = session.previous.threadId;
                    assert.ok(rootThreadId);
                    fixture.native.backgroundTerminals.set(rootThreadId, new Set(['notification-client']));
                    await fixture.writeReport('Report delivered before the start acknowledgment.');
                    fixture.native.finish(rootThreadId);
                    return delivered;
                },
            });
        },
    };
    const runtime = createReviewerRuntime({...options(fixture), nativeSessions});
    const accepted = succeeded(await runtime.execute({operation: 'spawn_agent', input: reviewerHandoff}));
    const completed = succeeded(await runtime.inspect({runId: accepted.runId}));
    assert.deepEqual(completed.completion, {status: 'ready', reportPath: reviewerHandoff.reportPath});
    assert.equal(fixture.native.backgroundTerminals.get(/** @type {string} */ (completed.threadId))?.size ?? 0, 0);
    await runtime.close();
});

test('a missing bound report still finishes Reviewer terminal cleanup without ready delivery', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime, observed} = await start(fixture);
    const threadId = /** @type {string} */ (observed.threadId);
    fixture.native.backgroundTerminals.set(threadId, new Set(['notification-client']));
    fixture.native.finish(threadId);
    const completed = succeeded(await runtime.inspect({runId: observed.runId}));
    assert.equal(completed.completion?.status, 'incomplete');
    assert.equal(fixture.native.backgroundTerminals.get(threadId)?.size ?? 0, 0);
    await runtime.close();
});

test('failed recovery save cannot publish a cleaned Reviewer turn as ready', async () => {
    const fixture = createReviewerRuntimeFixture();
    let failRecoverySave = false;
    let recoveryLogicalPath = '';
    const filesystem = {
        async open(/** @type {Parameters<typeof fixture.filesystem.open>[0]} */ input) {
            const opened = await fixture.filesystem.open(input);
            if (opened.status !== 'succeeded') return opened;
            const original = opened.scopedFilesystem;
            return {...opened, scopedFilesystem: Object.assign(Object.create(original), {
                async write(/** @type {Parameters<typeof original.write>[0]} */ request) {
                    if (failRecoverySave && request.path === recoveryLogicalPath) {
                        return {status: 'blocked', error: {code: 'injected-save-failure', message: 'Injected recovery save failure.'}};
                    }
                    return original.write(request);
                },
            })};
        },
    };
    const runtime = createReviewerRuntime({...options(fixture), filesystem});
    const accepted = succeeded(await runtime.execute({operation: 'spawn_agent', input: reviewerHandoff}));
    const active = succeeded(await runtime.inspect({runId: accepted.runId}));
    const threadId = /** @type {string} */ (active.threadId);
    recoveryLogicalPath = relative(reviewerHandoff.cwd, active.recoveryPath).split('\\').join('/');
    fixture.native.backgroundTerminals.set(threadId, new Set(['notification-client']));
    await fixture.writeReport('The original full report.');
    failRecoverySave = true;
    fixture.native.finish(threadId);
    const blocked = await runtime.inspect({runId: accepted.runId});
    assert.notEqual(blocked.status === 'succeeded' ? blocked.result.completion?.status : null, 'ready');
    assert.equal(runtime.holdsRun(accepted.runId), true);
    failRecoverySave = false;
    const recovered = succeeded(await runtime.inspect({runId: accepted.runId}));
    assert.deepEqual(recovered.completion, {status: 'ready', reportPath: reviewerHandoff.reportPath});
    assert.equal(recovered.threadId, threadId);
    assert.equal(fixture.native.calls.filter(call => call.operation === 'startTurn').length, 1);
    await runtime.close();
});

test('unknown final idle facts cannot leave a saved ready Reviewer result', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime, observed} = await start(fixture);
    const threadId = /** @type {string} */ (observed.threadId);
    fixture.native.backgroundTerminals.set(threadId, new Set(['notification-client']));
    fixture.native.completionBehaviors.set(threadId, async () => {throw new Error('Injected final idle facts unavailable.');});
    await fixture.writeReport('The complete bound report.');
    fixture.native.finish(threadId);
    const blocked = succeeded(await runtime.inspect({runId: observed.runId}));
    assert.equal(blocked.completion?.status, 'incomplete');
    assert.match(String(blocked.completion?.reason), /idle facts unavailable/u);
    const opened = await fixture.filesystem.open({root: reviewerHandoff.cwd});
    assert.equal(opened.status, 'succeeded');
    if (opened.status !== 'succeeded') throw new Error('Scripted repository unavailable.');
    const logicalPath = relative(reviewerHandoff.cwd, observed.recoveryPath).split('\\').join('/');
    const saved = await readReviewerSessionRecord(opened.scopedFilesystem, observed.recoveryPath, logicalPath);
    assert.notEqual(saved?.completion?.status, 'ready');
    fixture.native.completionBehaviors.delete(threadId);
    const recovered = succeeded(await runtime.inspect({runId: observed.runId}));
    assert.deepEqual(recovered.completion, {status: 'ready', reportPath: reviewerHandoff.reportPath});
    assert.equal(recovered.threadId, threadId);
    assert.equal(fixture.native.calls.filter(call => call.operation === 'startTurn').length, 1);
    await runtime.close();
});

test('historical completions leave no live Reviewer handles and remain readable through saved bindings', async () => {
    const fixture = createReviewerRuntimeFixture();
    /** @type {string[]} */ const retiredRuns = [];
    /** @type {()=>void} */ let acknowledge = () => {};
    const runtime = createReviewerRuntime({...options(fixture),onRetired: runId => {retiredRuns.push(runId);acknowledge();}});
    for (let index = 0; index < 4; index++) {
        await fixture.writeReport('');
        const handoff = {...reviewerHandoff,identity: {kind: /** @type {const} */ ('isolated'),instanceId: `history-${index}`}};
        const accepted = succeeded(await runtime.execute({operation: 'spawn_agent',input: handoff}));
        const active = succeeded(await runtime.inspect({runId: accepted.runId}));
        await fixture.writeReport(`Complete report ${index}.`);
        const retired = new Promise(resolve => {acknowledge = () => resolve(undefined);});
        fixture.native.finish(/** @type {string} */ (active.threadId));
        await retired;
        assert.equal(runtime.hasLiveRuns(), false);
        const managed = await managedBinding(fixture, active, 'running');
        const cold = succeeded(await runtime.inspect({runId: accepted.runId,managed}));
        assert.equal(cold.completion?.status, 'ready');
        assert.ok(cold.measurement);
    }
    assert.equal(new Set(retiredRuns).size, 4);
    await runtime.close();
});

test('fresh isolation and pre-turn additional Agents reject work before its model turn', async () => {
    for (const variant of ['parent', 'history', 'helper']) {
        const fixture = createReviewerRuntimeFixture();
        const nativeSessions = {
            async open(/** @type {Parameters<typeof fixture.native.nativeSessions.open>[0]} */ input) {
                const session = await fixture.native.nativeSessions.open(input);
                return Object.assign(Object.create(session), {
                    async prepareNativeStart() {
                        const native = await session.prepareNativeStart();
                        const root = fixture.native.members.get(native.threadId);
                        assert.ok(root);
                        if (variant === 'parent') root.parentThreadId = 'other-thread';
                        if (variant === 'history') root.hasConversationHistory = true;
                        if (variant === 'helper') fixture.native.addHelper(native.threadId);
                        return native;
                    },
                });
            },
        };
        const runtime = createReviewerRuntime({...options(fixture), nativeSessions});
        const accepted = succeeded(await runtime.execute({operation: 'spawn_agent', input: reviewerHandoff}));
        const result = succeeded(await runtime.inspect({runId: accepted.runId}));
        assert.equal(result.state, 'failed');
        assert.equal(result.completion?.status, 'incomplete');
        assert.equal(fixture.native.calls.filter(call => call.operation === 'startTurn' && call.threadId === result.threadId).length, 0);
        assert.equal(fixture.native.sessions[0].environmentState, 'exited');
        await runtime.close();
    }
});

test('failure before native thread creation preserves a readable incomplete recovery record', async () => {
    const fixture = createReviewerRuntimeFixture();
    const nativeSessions = {
        async open(/** @type {Parameters<typeof fixture.native.nativeSessions.open>[0]} */ input) {
            const session = await fixture.native.nativeSessions.open(input);
            return Object.assign(Object.create(session), {async prepareNativeStart() {
                throw new Error('Injected native start failure.');
            }});
        },
    };
    const runtime = createReviewerRuntime({...options(fixture), nativeSessions});
    const accepted = succeeded(await runtime.execute({operation: 'spawn_agent', input: reviewerHandoff}));
    const observed = succeeded(await runtime.inspect({runId: accepted.runId}));
    assert.equal(observed.threadId, null);
    assert.equal(observed.completion?.status, 'incomplete');
    const opened = await fixture.filesystem.open({root: reviewerHandoff.cwd});
    assert.equal(opened.status, 'succeeded');
    if (opened.status !== 'succeeded') throw new Error('Scripted repository unavailable.');
    const logical = relative(reviewerHandoff.cwd, observed.recoveryPath).split('\\').join('/');
    const recovered = await readReviewerSessionRecord(opened.scopedFilesystem, observed.recoveryPath, logical);
    assert.equal(recovered?.runId, accepted.runId);
    assert.equal(recovered.threadId, null);
    await runtime.close();
});

test('followup_task reuses the original run and native Thread.id with current settings and a new measurement baseline', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime, observed} = await start(fixture);
    const threadId = /** @type {string} */ (observed.threadId);
    const root = fixture.native.members.get(threadId);
    assert.ok(root);
    root.usage = createUsage(40);
    await fixture.writeReport('First full report.');
    fixture.native.finish(threadId);
    assert.equal(succeeded(await runtime.inspect({runId: observed.runId})).completion?.status, 'ready');
    const newReport = `${reviewerHandoff.writePaths[0]}/next.md`;
    await fixture.writeReport('', newReport);
    const nextHandoff = {...reviewerHandoff, reportPath: newReport,
        settings: {...reviewerHandoff.settings, model: 'next-model'}};
    const accepted = succeeded(await runtime.execute({operation: 'followup_task', input: {...nextHandoff, runId: observed.runId}}));
    assert.equal(accepted.runId, observed.runId);
    assert.equal(accepted.threadId, threadId);
    assert.equal(accepted.deliveryStatus, 'accepted');
    const next = succeeded(await runtime.inspect({runId: observed.runId}));
    assert.equal(next.threadId, threadId);
    assert.notEqual(next.turnId, observed.turnId);
    assert.equal(next.completion, null);
    assert.equal(fixture.native.calls.filter(call => call.operation === 'start').length, 1);
    assert.equal(fixture.native.calls.filter(call => call.operation === 'acceptTask').length, 1);
    root.usage = createUsage(45);
    await fixture.writeReport('Second full report.', newReport);
    fixture.native.finish(threadId);
    const result = succeeded(await runtime.inspect({runId: observed.runId}));
    assert.equal(result.completion?.status, 'ready');
    assert.equal(result.measurement?.usage.totalTokens, 5);
    assert.deepEqual(result.measurement?.members.map(member => member.threadId), [threadId]);
    await runtime.close();
});

test('a follow-up cannot replace active work and a completed run can reattach without a new native thread', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime, observed} = await start(fixture);
    const nextReport = `${reviewerHandoff.writePaths[0]}/followup.md`;
    await fixture.writeReport('', nextReport);
    failed(await runtime.execute({operation: 'followup_task', input: {...reviewerHandoff, runId: observed.runId,
        reportPath: nextReport}}), 'reviewer-busy');
    assert.equal(fixture.native.calls.filter(call => call.operation === 'acceptTask').length, 0);
    await fixture.writeReport('Complete original report.');
    fixture.native.finish(/** @type {string} */ (observed.threadId));
    succeeded(await runtime.inspect({runId: observed.runId}));
    await runtime.close();
    const restored = createReviewerRuntime(options(fixture));
    const accepted = succeeded(await restored.execute({operation: 'followup_task', input: {...reviewerHandoff,
        runId: observed.runId, reportPath: nextReport}}));
    assert.equal(accepted.runId, observed.runId);
    const next = succeeded(await restored.inspect({runId: observed.runId}));
    assert.equal(next.threadId, observed.threadId);
    assert.equal(fixture.native.calls.filter(call => call.operation === 'start').length, 1);
    assert.equal(fixture.native.calls.filter(call => call.operation === 'resume').length, 1);
    await restored.close();
});

test('a crashed saved running review becomes incomplete before explicit work resumes its original thread', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime, observed} = await start(fixture);
    const threadId = /** @type {string} */ (observed.threadId);
    const originalTurn = observed.turnId;
    const root = fixture.native.members.get(threadId);
    assert.ok(root);
    root.usage = createUsage(25);
    await runtime.close();
    fixture.native.sessions[0].environmentState = 'exited';
    root.state = 'exited';
    fixture.clock.advance(500);
    const reportPath = `${reviewerHandoff.writePaths[0]}/after-crash.md`;
    await fixture.writeReport('', reportPath);
    let checkedOldRound = false;
    const nativeSessions = {
        async open(/** @type {Parameters<typeof fixture.native.nativeSessions.open>[0]} */ input) {
            const session = await fixture.native.nativeSessions.open(input);
            return Object.assign(Object.create(session), {
                async acceptTask(/** @type {Parameters<typeof session.acceptTask>[0]} */ task) {
                    const opened = await fixture.filesystem.open({root: reviewerHandoff.cwd});
                    assert.equal(opened.status, 'succeeded');
                    if (opened.status !== 'succeeded') throw new Error('Scripted repository unavailable.');
                    const path = relative(reviewerHandoff.cwd, observed.recoveryPath).split('\\').join('/');
                    const old = await readReviewerSessionRecord(opened.scopedFilesystem, observed.recoveryPath, path);
                    assert.equal(old?.runId, observed.runId);
                    assert.equal(old.state, 'stopped');
                    assert.equal(old.environmentState, 'exited');
                    assert.equal(old.completion?.status, 'incomplete');
                    assert.equal(old.measurement.finishedAt, null);
                    checkedOldRound = true;
                    return session.acceptTask(task);
                },
            });
        },
    };
    const restored = createReviewerRuntime({...options(fixture), nativeSessions});
    assert.equal(fixture.native.calls.filter(call => call.operation === 'resume').length, 0);
    const accepted = succeeded(await restored.execute({operation: 'followup_task', input: {
        ...reviewerHandoff, runId: observed.runId, reportPath, handoff: 'Explicit work after crash.',
    }}));
    assert.equal(checkedOldRound, true);
    assert.equal(accepted.runId, observed.runId);
    assert.equal(accepted.threadId, threadId);
    const next = succeeded(await restored.inspect({runId: observed.runId}));
    assert.equal(next.threadId, threadId);
    assert.notEqual(next.turnId, originalTurn);
    assert.equal(next.measurement?.startedAt, fixture.clock.now());
    assert.equal(fixture.native.calls.filter(call => call.operation === 'start').length, 1);
    assert.equal(fixture.native.calls.filter(call => call.operation === 'resume').length, 1);
    assert.equal(fixture.native.calls.filter(call => call.operation === 'startTurn').length, 2);
    assert.match(fixture.native.calls.filter(call => call.operation === 'startTurn').at(-1)?.text ?? '', /Explicit work after crash/);
    root.usage = createUsage(30);
    await fixture.writeReport('New complete report.', reportPath);
    fixture.native.finish(threadId);
    const finished = succeeded(await restored.inspect({runId: observed.runId}));
    assert.equal(finished.completion?.status, 'ready');
    assert.equal(finished.measurement?.usage.totalTokens, 5);
    await restored.close();
});

test('cold inspection uses the exact saved managed binding and never opens a native session', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime, observed} = await start(fixture);
    await runtime.close();
    const opened = await fixture.filesystem.open({root: reviewerHandoff.cwd});
    assert.equal(opened.status, 'succeeded');
    if (opened.status !== 'succeeded') throw new Error('Scripted repository unavailable.');
    const logical = relative(reviewerHandoff.cwd, observed.recoveryPath).split('\\').join('/');
    const record = await readReviewerSessionRecord(opened.scopedFilesystem, observed.recoveryPath, logical);
    assert.ok(record);
    const managed = /** @type {import('../../lib/background-agent/state-store.mjs').BackgroundAgentRow} */ (/** @type {unknown} */ ({
        runId: observed.runId, role: record.role, threadId: record.threadId, sessionPath: record.sessionPath,
        recoveryPath: backgroundAgentRecoveryPath({stateDirectory: reviewerHandoff.stateDirectory,runId: observed.runId}),
        cwd: record.cwd, readPaths: record.readPaths, writePaths: record.writePaths, settings: record.settings, state: 'exited',
    }));
    const before = fixture.native.calls.length;
    const uncertain = createReviewerRuntime(options(fixture));
    const unknown = succeeded(await uncertain.inspect({runId: observed.runId, managed: {...managed,state: 'unknown'}}));
    assert.equal(unknown.state, 'running');
    assert.equal(unknown.measurement?.wallClockMs, null);
    await uncertain.close();
    const restored = createReviewerRuntime(options(fixture));
    const inspected = succeeded(await restored.inspect({runId: observed.runId,managed}));
    assert.equal(inspected.threadId, observed.threadId);
    assert.equal(inspected.state, 'stopped');
    assert.equal(inspected.completion?.status, 'incomplete');
    assert.equal(inspected.measurement?.wallClockMs, null);
    assert.equal(fixture.native.calls.length, before);
    await restored.close();
    record.threadId = 'different-thread';
    await saveReviewerSessionRecord(opened.scopedFilesystem, record, logical);
    const mismatch = createReviewerRuntime(options(fixture));
    failed(await mismatch.inspect({runId: observed.runId,managed}), 'recovery-identity-mismatch');
    assert.equal(fixture.native.calls.length, before);
    await mismatch.close();
    record.threadId = observed.threadId;
    record.failure = {code: 'reviewer-group-violation',message: 'Saved native group violation.'};
    record.state = 'failed';
    await saveReviewerSessionRecord(opened.scopedFilesystem, record, logical);
    const priorFailure = createReviewerRuntime(options(fixture));
    const failedReview = succeeded(await priorFailure.inspect({runId: observed.runId,managed}));
    assert.equal(failedReview.state, 'failed');
    assert.equal(failedReview.completion?.status, 'incomplete');
    await priorFailure.close();
});

test('a crashed saved starting review remains incomplete with unknown wall time when no new work is accepted', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime, observed} = await start(fixture);
    const threadId = /** @type {string} */ (observed.threadId);
    await runtime.close();
    fixture.native.sessions[0].environmentState = 'exited';
    const root = fixture.native.members.get(threadId);
    assert.ok(root);
    root.state = 'exited';
    const opened = await fixture.filesystem.open({root: reviewerHandoff.cwd});
    assert.equal(opened.status, 'succeeded');
    if (opened.status !== 'succeeded') throw new Error('Scripted repository unavailable.');
    const recoveryFile = relative(reviewerHandoff.cwd, observed.recoveryPath).split('\\').join('/');
    const saved = await readReviewerSessionRecord(opened.scopedFilesystem, observed.recoveryPath, recoveryFile);
    assert.ok(saved);
    saved.state = 'starting';
    await saveReviewerSessionRecord(opened.scopedFilesystem, saved, recoveryFile);
    fixture.clock.advance(900);
    const reportPath = `${reviewerHandoff.writePaths[0]}/not-accepted.md`;
    await fixture.writeReport('', reportPath);
    const nativeSessions = {
        async open(/** @type {Parameters<typeof fixture.native.nativeSessions.open>[0]} */ input) {
            const session = await fixture.native.nativeSessions.open(input);
            return Object.assign(Object.create(session), {
                async acceptTask() {throw new Error('Injected acceptance failure.');},
            });
        },
    };
    const restored = createReviewerRuntime({...options(fixture), nativeSessions});
    failed(await restored.execute({operation: 'followup_task', input: {...reviewerHandoff,
        runId: observed.runId, reportPath, handoff: 'Explicit later work.',
    }}), 'reviewer-runtime-failed');
    const previous = succeeded(await restored.inspect({runId: observed.runId}));
    assert.equal(previous.state, 'stopped');
    assert.equal(previous.completion?.status, 'incomplete');
    assert.equal(previous.measurement?.finishedAt, null);
    assert.equal(previous.measurement?.wallClockMs, null);
    assert.equal(fixture.native.calls.filter(call => call.operation === 'startTurn').length, 1);
    await restored.close();
});

test('an active additional Agent blocks a new follow-up turn on the original Reviewer', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime, observed} = await start(fixture);
    const threadId = /** @type {string} */ (observed.threadId);
    await fixture.writeReport('Original full report.');
    fixture.native.finish(threadId);
    succeeded(await runtime.inspect({runId: observed.runId}));
    const reportPath = `${reviewerHandoff.writePaths[0]}/blocked-followup.md`;
    await fixture.writeReport('', reportPath);
    fixture.native.addHelper(threadId);
    const turns = fixture.native.calls.filter(call => call.operation === 'startTurn' && call.threadId === threadId).length;
    failed(await runtime.execute({operation: 'followup_task', input: {...reviewerHandoff,
        runId: observed.runId, reportPath}}), 'reviewer-group-violation');
    assert.equal(fixture.native.calls.filter(call => call.operation === 'startTurn' && call.threadId === threadId).length, turns);
    assert.equal(fixture.native.sessions.at(-1)?.environmentState, 'exited');
    await runtime.close();
});

test('an unloaded Reviewer reattaches by the same run and Thread.id before its next complete task', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime, observed} = await start(fixture);
    const threadId = /** @type {string} */ (observed.threadId);
    await fixture.writeReport('Original full report.');
    fixture.native.finish(threadId);
    succeeded(await runtime.inspect({runId: observed.runId}));
    fixture.native.sessions[0].environmentState = 'exited';
    const root = fixture.native.members.get(threadId);
    assert.ok(root);
    root.state = 'exited';
    const managed = await managedBinding(fixture, observed, 'exited');
    assert.equal(succeeded(await runtime.inspect({runId: observed.runId,managed})).state, 'stopped');
    assert.equal(succeeded(await runtime.inspect({runId: observed.runId,managed})).completion?.status, 'ready');
    const reportPath = `${reviewerHandoff.writePaths[0]}/unloaded-followup.md`;
    await fixture.writeReport('', reportPath);
    const accepted = succeeded(await runtime.execute({operation: 'followup_task', input: {...reviewerHandoff,
        runId: observed.runId, reportPath}}));
    const next = succeeded(await runtime.inspect({runId: accepted.runId}));
    assert.equal(next.threadId, threadId);
    assert.equal(fixture.native.calls.filter(call => call.operation === 'resume').length, 1);
    assert.equal(fixture.native.calls.filter(call => call.operation === 'start').length, 1);
    await runtime.close();
});

test('an unexpected extra Agent invalidates the result while ended historical members do not enter usage', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime, observed} = await start(fixture);
    const threadId = /** @type {string} */ (observed.threadId);
    const root = fixture.native.members.get(threadId);
    assert.ok(root);
    root.usage = createUsage(8);
    const childId = fixture.native.addHelper(threadId);
    const child = fixture.native.members.get(childId);
    assert.ok(child);
    child.usage = createUsage(70);
    const result = succeeded(await runtime.inspect({runId: observed.runId}));
    assert.equal(result.completion?.status, 'incomplete');
    assert.equal(result.state, 'failed');
    assert.equal(fixture.native.sessions[0].environmentState, 'exited');
    assert.deepEqual(result.measurement?.members.map(member => member.threadId), [threadId]);
    assert.equal(runtime.holdsRun(observed.runId), false);
    await runtime.close();
});

test('an explicit incomplete final retires without a report', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime,observed} = await start(fixture);
    const threadId = /** @type {string} */ (observed.threadId);
    assert.equal(runtime.holdsRun(observed.runId),true);
    fixture.native.finish(threadId,'{"status":"incomplete","reason":"Evidence remains unknown."}');
    const result = succeeded(await runtime.inspect({runId:observed.runId}));
    assert.equal(result.completion?.status,'incomplete');
    assert.equal(runtime.holdsRun(observed.runId),false);
    await runtime.close();
});

test('native manual requests do not themselves fail or stop the Reviewer and unknown facts cannot authorize ready', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime, observed} = await start(fixture);
    fixture.native.sessions[0].clientRequests.push({requestId: 'permission-1', kind: 'approval',
        method: 'item/commandExecution/requestApproval', params: {},
        threadId: observed.threadId, turnId: observed.turnId});
    const pending = succeeded(await runtime.inspect({runId: observed.runId}));
    assert.equal(pending.state, 'running');
    assert.equal(fixture.native.sessions[0].environmentState, 'running');
    assert.equal(fixture.native.calls.filter(call => call.operation === 'stop').length, 0);
    fixture.native.sessions[0].clientRequests.length = 0;
    fixture.native.sessions[0].factsComplete = false;
    await fixture.writeReport('Full report.');
    fixture.native.finish(/** @type {string} */ (observed.threadId));
    const unknown = succeeded(await runtime.inspect({runId: observed.runId}));
    assert.equal(unknown.completion?.status, 'incomplete');
    assert.equal(unknown.measurement?.usage.totalTokens, null);
    await runtime.close();
});

test('interrupt_agent binds the exact active turn, and close only detaches control', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime, observed} = await start(fixture);
    failed(await runtime.execute({operation: 'interrupt_agent', input: {runId: observed.runId, turnId: 'old-turn'}}), 'turn-mismatch');
    const interrupted = succeeded(await runtime.execute({operation: 'interrupt_agent', input: {
        runId: observed.runId, turnId: observed.turnId,
    }}));
    assert.equal(interrupted.accepted, true);
    assert.equal(runtime.holdsRun(observed.runId), false);
    assert.equal(fixture.native.sessions[0].environmentState, 'running');
    const managed = await managedBinding(fixture, observed, 'running');
    assert.equal(succeeded(await runtime.inspect({runId: observed.runId,managed})).completion?.status, 'incomplete');
    assert.equal((await runtime.close()).status, 'succeeded');
    assert.equal(fixture.native.sessions[0].environmentState, 'running');
    failed(await runtime.execute({operation: 'resume', input: {runId: observed.runId}}), 'runtime-closed');
});

test('only repository temporary write scope and a complete current bound report can authorize delivery', async () => {
    const fixture = createReviewerRuntimeFixture();
    const runtime = createReviewerRuntime(options(fixture));
    failed(await runtime.execute({operation: 'spawn_agent', input: {...reviewerHandoff,
        writePaths: [reviewerHandoff.cwd]}}), 'invalid-input');
    failed(await runtime.execute({operation: 'spawn_agent', input: {...reviewerHandoff,
        readPaths: ['/another-repository']}}), 'invalid-input');
    assert.equal(fixture.native.sessions.length, 0);
    const accepted = succeeded(await runtime.execute({operation: 'spawn_agent', input: reviewerHandoff}));
    const observed = succeeded(await runtime.inspect({runId: accepted.runId}));
    fixture.native.finish(/** @type {string} */ (observed.threadId));
    const empty = succeeded(await runtime.inspect({runId: accepted.runId}));
    assert.equal(empty.completion?.status, 'incomplete');
    await fixture.writeReport('Full report, personally written by the Reviewer.');
    assert.equal(succeeded(await runtime.inspect({runId: accepted.runId})).completion?.status, 'ready');
    await fixture.writeReport('');
    const managed = await managedBinding(fixture, observed, 'running');
    assert.equal(succeeded(await runtime.inspect({runId: accepted.runId,managed})).completion?.status, 'incomplete');
    await runtime.close();
});

test('report and write-path ancestor links are rejected before native admission', async t => {
    const repositoryRoot = await createTemporaryDirectory(t, 'arw-reviewer-scope-');
    const cwd = join(repositoryRoot, 'audited');
    const external = join(repositoryRoot, 'external');
    const reportDirectory = join(cwd, '.tmp', 'reports');
    const linkedDirectory = join(cwd, '.tmp', 'redirect');
    const stateDirectory = join(repositoryRoot, '.tmp', 'codex', 'test-session', '0093_01', 'runtime');
    await Promise.all([mkdir(reportDirectory, {recursive: true}), mkdir(external), mkdir(stateDirectory, {recursive: true})]);
    await Promise.all([writeFile(join(external, 'report.md'), ''), writeFile(join(reportDirectory, 'report.md'), '')]);
    await symlink(external, linkedDirectory);
    const native = createScriptedReviewerSessions();
    const runtime = createReviewerRuntime({nativeSessions: native.nativeSessions,
        recoveryBoundary: () => ({repositoryRoot, sessionWorkspaceRoot: join(repositoryRoot, '.tmp', 'codex', 'test-session')})});
    const handoff = {...reviewerHandoff, cwd, stateDirectory};
    failed(await runtime.execute({operation: 'spawn_agent', input: {...handoff,
        writePaths: [join(cwd, '.tmp')], reportPath: join(linkedDirectory, 'report.md')}}), 'report-binding-invalid');
    failed(await runtime.execute({operation: 'spawn_agent', input: {...handoff,
        writePaths: [reportDirectory, linkedDirectory], reportPath: join(reportDirectory, 'report.md')}}), 'invalid-input');
    assert.equal(native.calls.length, 0);
    assert.equal(await readFile(join(external, 'report.md'), 'utf8'), '');
    await runtime.close();
});

test('a bound report hard link is rejected both before work and at completion', async t => {
    const repositoryRoot = await createTemporaryDirectory(t, 'arw-reviewer-hardlink-');
    const cwd = join(repositoryRoot, 'audited');
    const reportDirectory = join(cwd, '.tmp', 'reports');
    const reportPath = join(reportDirectory, 'report.md');
    const otherLink = join(repositoryRoot, 'other-report.md');
    const stateDirectory = join(repositoryRoot, '.tmp', 'codex', 'test-session', '0093_01', 'runtime');
    await Promise.all([mkdir(reportDirectory, {recursive: true}), mkdir(stateDirectory, {recursive: true})]);
    await writeFile(otherLink, '');
    await link(otherLink, reportPath);
    const native = createScriptedReviewerSessions();
    const runtime = createReviewerRuntime({nativeSessions: native.nativeSessions,
        recoveryBoundary: () => ({repositoryRoot, sessionWorkspaceRoot: join(repositoryRoot, '.tmp', 'codex', 'test-session')})});
    const handoff = {...reviewerHandoff, cwd, stateDirectory, writePaths: [reportDirectory], reportPath};
    failed(await runtime.execute({operation: 'spawn_agent', input: handoff}), 'report-binding-invalid');
    assert.equal(native.calls.length, 0);
    await rm(reportPath);
    await writeFile(reportPath, '');
    const accepted = succeeded(await runtime.execute({operation: 'spawn_agent', input: handoff}));
    const observed = succeeded(await runtime.inspect({runId: accepted.runId}));
    await rm(reportPath);
    await writeFile(otherLink, 'A nonempty file outside the audited repository.');
    await link(otherLink, reportPath);
    native.finish(/** @type {string} */ (observed.threadId));
    assert.equal(succeeded(await runtime.inspect({runId: accepted.runId})).completion?.status, 'incomplete');
    assert.equal(await readFile(otherLink, 'utf8'), 'A nonempty file outside the audited repository.');
    await runtime.close();
});

test('the Reviewer record is saved only at meaningful transitions, not every unchanged observation', async () => {
    const fixture = createReviewerRuntimeFixture();
    const {runtime, observed} = await start(fixture);
    const recoveryRelative = relative(reviewerHandoff.cwd, observed.recoveryPath).split('\\').join('/');
    const before = fixture.filesystem.calls.filter(call => call.operation === 'write' && call.path === recoveryRelative).length;
    for (let index = 0; index < 4; index++) succeeded(await runtime.inspect({runId: observed.runId}));
    const after = fixture.filesystem.calls.filter(call => call.operation === 'write' && call.path === recoveryRelative).length;
    assert.equal(after, before);
    await runtime.close();
});


test('passive telemetry parse failure preserves a legal bound report and existing-event measurement without extra work',async()=>{
    const fixture=createReviewerRuntimeFixture();let failure='';
    const receiver=createModelTelemetryReceiver({onFailure:reason=>{failure=reason;}});
    assert.deepEqual(receiver.consume({resourceLogs:'invalid'}),[]);assert.ok(failure);
    const nativeSessions={open:async(/** @type {Parameters<typeof fixture.native.nativeSessions.open>[0]} */ input)=>{
        const session=await fixture.native.nativeSessions.open(input);
        const snapshot=session.snapshot;
        return Object.assign(session,{snapshot:async(/** @type {Parameters<typeof session.snapshot>[0]} */ request)=>({
            ...await snapshot(request),measurementFacts:{requestsComplete:false,workCoverage:{complete:false,basis:failure}},
        })});
    }};
    const runtime=createReviewerRuntime({...options(fixture),nativeSessions});
    const accepted=succeeded(await runtime.execute({operation:'spawn_agent',input:reviewerHandoff}));
    const active=succeeded(await runtime.inspect({runId:accepted.runId}));
    fixture.clock.advance(25);await fixture.writeReport('Complete current bound report.');
    fixture.native.finish(/** @type {string} */(active.threadId));
    const final=succeeded(await runtime.inspect({runId:accepted.runId}));
    assert.equal(final.completion?.status,'ready');assert.equal(final.measurement?.workDuration.estimated,true);
    assert.ok(final.measurement?.workDuration.basis?.includes(failure));
    assert.equal(final.measurement?.modelPhases.totalRequests,null);
    assert.equal(fixture.native.calls.some(call=>call.operation==='steer'||call.operation==='interruptGroup'||call.operation==='stop'),false);
    await runtime.close();await receiver.close();
});
