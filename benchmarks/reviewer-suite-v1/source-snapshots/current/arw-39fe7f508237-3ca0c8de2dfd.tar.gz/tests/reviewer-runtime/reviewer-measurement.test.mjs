import assert from 'node:assert/strict';
import test from 'node:test';
import {cloneJsonValue} from '../../lib/common/json.mjs';
import {createModelTelemetryReceiver, mergeModelResponseMeasurement} from '../../lib/background-agent/model-telemetry.mjs';
import {
    createReviewerMeasurement, createUsage, observeReviewerMeasurement, reviewerMeasurementResult, reviewerMeasurementRates,
} from '../../lib/reviewer-runtime/reviewer-measurement.mjs';

/** @typedef {import('../../lib/background-agent/codex-app-server.mjs').NativeMember} NativeMember */
/** @param {string} threadId @param {number | null} value @returns {NativeMember} */
const member = (threadId, value) => ({
    threadId, parentThreadId: threadId === 'root' ? null : 'root', hasConversationHistory: true, state: 'idle', turnId: 'turn',
    sessionPath: `/native/${threadId}.jsonl`, modelProvider: 'provider', contexts: [],
    usage: createUsage(value), finalResponse: null,
});

test('Reviewer measurement deduplicates the original Thread.id across recovery and ignores historical Agent usage', () => {
    const root = member('root', 100);
    const historical = member('historical', 50);
    const measurement = createReviewerMeasurement({startedAt: 1_000, members: [root, historical], rootThreadId: 'root'});
    root.usage = {...createUsage(130), cachedInputTokens: 110, reasoningOutputTokens: 120};
    historical.usage = createUsage(10_000);
    const observation = {members: [root, historical], rootThreadId: 'root'};
    observeReviewerMeasurement(measurement, observation);
    observeReviewerMeasurement(measurement, observation);
    assert.equal(reviewerMeasurementResult(measurement, 1_500).usage.totalTokens, 30);
    assert.equal(reviewerMeasurementResult(measurement, 1_500).usage.cachedInputTokens, 10);
    const resumed = /** @type {typeof measurement} */ (cloneJsonValue(measurement));
    root.usage.inputTokens = 140;
    observeReviewerMeasurement(resumed, observation);
    resumed.finishedAt = 2_000;
    const result = reviewerMeasurementResult(resumed, 9_000);
    assert.equal(result.usage.inputTokens, 40);
    assert.equal(result.wallClockMs, 1_000);
    assert.deepEqual(result.members.map(entry => entry.threadId), ['root']);
});

test('Fresh Reviewer measurement uses the first actual cumulative usage and retains unknown telemetry', () => {
    const root = member('root', null);
    const historical = member('historical', 100);
    const measurement = createReviewerMeasurement({startedAt: 1_000, members: [root, historical], rootThreadId: 'root', freshRoot: 'root'});
    assert.equal(reviewerMeasurementResult(measurement, 1_000).usage.totalTokens, null);
    root.usage = createUsage(20);
    observeReviewerMeasurement(measurement, {members: [root, historical], rootThreadId: 'root'});
    assert.equal(reviewerMeasurementResult(measurement, 1_200).usage.totalTokens, 20);
    assert.equal(Object.hasOwn(reviewerMeasurementResult(measurement, 1_200).usage, 'costUsd'), false);
    observeReviewerMeasurement(measurement, {members: [historical], rootThreadId: 'root'});
    assert.equal(reviewerMeasurementResult(measurement, 1_300, false).usage.totalTokens, null);
    observeReviewerMeasurement(measurement, {members: [root, historical], rootThreadId: 'root'});
    assert.equal(reviewerMeasurementResult(measurement, 1_400).usage.totalTokens, 20);
    const unknownBaseline = createReviewerMeasurement({startedAt: 1_000, members: [member('root', null)], rootThreadId: 'root'});
    observeReviewerMeasurement(unknownBaseline, {members: [root], rootThreadId: 'root'});
    assert.equal(reviewerMeasurementResult(unknownBaseline, 1_400).usage.totalTokens, null);
});

test('Passive response samples produce paired rates and retain working tool waits across overlapping downtime and recovery', () => {
    /** @type {Map<string,import('../../lib/background-agent/model-telemetry.mjs').NativeResponseMeasurement>} */
    const responses = new Map();
    const receiver = createModelTelemetryReceiver({onObservation: observations => {
        for (const observation of observations) {
            const key = `${observation.threadId}/${observation.responseId}`;
            responses.set(key, mergeModelResponseMeasurement(responses.get(key), observation));
        }
    }});
    /** @param {string} threadId @param {string} responseId @param {number} at @param {string} kind @param {Record<string,string|number>} values */
    const record = (threadId, responseId, at, kind, values) => ({
        timeUnixNano: String(BigInt(at) * 1_000_000n), body: {stringValue: 'Private report content must not be retained.'},
        attributes: Object.entries({'event.name': 'codex.sse_event', 'conversation.id': threadId, 'response.id': responseId, kind, ...values})
            .map(([key, value]) => ({key, value: typeof value === 'number' ? {intValue: String(value)} : {stringValue: value}})),
    });
    /** @param {ReturnType<typeof record>[]} logRecords */
    const batch = logRecords => ({resourceLogs: [{resource: {attributes: []}, scopeLogs: [{logRecords}]}]});
    receiver.consume(batch([record('root', 'old', 500, 'response.completed', {request_started_at_ms: 100, input_tokens: 1000, cached_input_tokens: 100, output_tokens: 500})]));
    const root = member('root', 0);
    root.usage = {...createUsage(0), inputTokens: 1000, cachedInputTokens: 100, outputTokens: 500, reasoningOutputTokens: 100, totalTokens: 1500};
    const measurement = createReviewerMeasurement({startedAt: 1000, members: [root], rootThreadId: 'root', measurementFacts: {responses: [...responses.values()]}});
    const logs = [
        record('root', 'a', 1100, 'response.output_text.delta', {request_started_at_ms: 1000, delta: 'first', first_chunk_tokens: 1}),
        record('root', 'a', 1500, 'response.output_text.delta', {delta: 'last'}),
        record('root', 'a', 1550, 'response.completed', {input_tokens: 100, cached_input_tokens: 20, output_tokens: 21}),
        record('root', 'b', 5700, 'response.reasoning_text.delta', {request_started_at_ms: 5500, delta: 'reasoning'}),
        record('root', 'b', 6700, 'response.function_call_arguments.delta', {delta: '{"command":"wait"}'}),
        record('root', 'b', 6750, 'response.completed', {input_tokens: 200, cached_input_tokens: 50, output_tokens: 41}),
        record('other', 'a', 1100, 'response.output_text.delta', {request_started_at_ms: 1000, delta: 'other'}),
        record('other', 'a', 1300, 'response.completed', {input_tokens: 100000, cached_input_tokens: 0, output_tokens: 100000}),
        record('root', 'a', 9000, 'tool.stdout', {delta: 'Normal tool waiting has no model token timing.'}),
    ];
    receiver.consume(batch(logs));
    receiver.consume(batch(logs));
    root.usage = {...createUsage(0), inputTokens: 1300, cachedInputTokens: 170, outputTokens: 562, reasoningOutputTokens: 140, totalTokens: 1862};
    const facts = {
        responses: [...responses.values()], requestsComplete: true, workCoverage: {complete: true},
        nonWork: [
            {startedAt: 3000, finishedAt: 5000},
            {startedAt: 4000, finishedAt: 6000, estimated: true, basis: '休眠边界依据原生生命周期观察估算.'},
        ],
    };
    observeReviewerMeasurement(measurement, {members: [root], rootThreadId: 'root',
        measurementFacts: {...facts, nonWork: [facts.nonWork[1]]}, now: 7000});
    observeReviewerMeasurement(measurement, {members: [root, member('other', 100000)], rootThreadId: 'root', measurementFacts: facts, now: 11000});
    const recovered = /** @type {typeof measurement} */(cloneJsonValue(measurement));
    observeReviewerMeasurement(recovered, {members: [root], rootThreadId: 'root', measurementFacts: facts, now: 11000});
    recovered.finishedAt = 11000;
    const result = reviewerMeasurementResult(recovered, 50000);
    const rates = reviewerMeasurementRates(result);
    assert.equal(result.wallClockMs, 10000);
    assert.equal(result.workDuration.durationMs, 7000);
    assert.equal(result.workDuration.estimated, true);
    assert.match(result.workDuration.basis ?? '', /生命周期/);
    assert.equal(result.usage.outputTokens, 62);
    assert.equal(result.usage.reasoningOutputTokens, 40);
    assert.equal(rates.average.inputTokensPerSecond, 230 / 7);
    assert.equal(rates.average.outputTokensPerSecond, 62 / 7);
    assert.equal(result.modelPhases.totalRequests, 2);
    assert.equal(result.modelPhases.input[0].tokens, 230);
    assert.equal(result.modelPhases.input[0].durationMs, 300);
    assert.equal(rates.model.input.tokensPerSecond, 230 / 0.3);
    assert.equal(result.modelPhases.output[0].tokens, 60);
    assert.equal(result.modelPhases.output[0].durationMs, 1400);
    assert.equal(rates.model.output.tokensPerSecond, 60 / 1.4);
    for (const group of [...result.modelPhases.input, ...result.modelPhases.output]) {
        assert.equal(group.measuredRequests, 2);
        assert.equal(group.source, 'existing-events');
        assert.equal(group.estimated, true);
        assert.ok(group.basis);
    }
    assert.match(result.modelPhases.output[0].basis ?? '', /首块 token 数未知/);
    assert.equal(JSON.stringify(recovered).includes('Private report content'), false);
});
