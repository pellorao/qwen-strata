import assert from 'node:assert/strict';
import test from 'node:test';
import {stripVTControlCharacters} from 'node:util';

import {renderBackgroundAgents} from '../../lib/background-agent/presentation.mjs';

test('background Agent overview uses four columns and retains full Main identity and elapsed time', () => {
    const fullId = '019caaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
    const fullTitle = '日本語の長い Main タイトル 😀';
    const result = renderBackgroundAgents([
        {role: 'code-spec-reviewer', ownerId: fullId, ownerTitle: fullTitle, state: 'running', taskElapsedMs: 3_661_000},
        {role: 'code-standards-reviewer', ownerId: 'main-2', ownerTitle: 'ASCII', state: 'idle', taskElapsedMs: 3_000},
        {role: 'commit-audit-reviewer', ownerId: 'main-3', ownerTitle: null, state: 'unknown', taskElapsedMs: null},
        {role: 'spec-readiness-reviewer', ownerId: 'main-4', ownerTitle: ' \t ', state: 'starting', taskElapsedMs: 0},
    ]);
    const [heading, divider, first, second, third, fourth] = result.split('\n');

    assert.match(heading, /^Status\s{2,}Role\s{2,}Main session\s{2,}Elapsed$/u);
    assert.match(divider, /^[- ]+$/u);
    assert.equal(divider.split(/ {2,}/u).length, 4);
    assert.ok(first.includes(`${fullTitle} (${fullId})`));
    assert.ok(first.endsWith('1:01:01'));
    assert.ok(second.endsWith('0:00:03'));
    assert.ok(second.includes('main-2'));
    assert.match(third, /\u001b\[90mN\/A\u001b\[0m/u);
    assert.match(fourth, /\u001b\[90mN\/A\u001b\[0m/u);
    assert.ok(third.includes('unknown'));
    assert.ok(third.includes('commit-audit-reviewer'));
    assert.ok(third.includes('main-3'));
    assert.ok(third.endsWith('  -'));
    assert.ok(fourth.endsWith('0:00:00'));
    assert.match(third, /\u001b\[90mN\/A\u001b\[0m \(main-3\)/u);
    assert.equal(result.includes('cwd'), false);
});

test('joined emoji, variation selectors and flags occupy one terminal grapheme width', () => {
    const family = '👨‍👩‍👧‍👦';
    const rows = renderBackgroundAgents([
        {role: 'reviewer', ownerId: 'root', ownerTitle: family, state: 'idle', taskElapsedMs: 0},
        {role: 'reviewer', ownerId: 'root', ownerTitle: 'AB', state: 'idle', taskElapsedMs: 0},
        {role: 'reviewer', ownerId: 'root', ownerTitle: '1️⃣', state: 'idle', taskElapsedMs: 0},
        {role: 'reviewer', ownerId: 'root', ownerTitle: '🇯🇵', state: 'idle', taskElapsedMs: 0},
        {role: 'reviewer', ownerId: 'root', ownerTitle: '👁‍🗨', state: 'idle', taskElapsedMs: 0},
    ]).split('\n').slice(2);
    const gap = (/** @type {string} */ row) => row.slice(row.indexOf('(root)') + '(root)'.length, row.indexOf('0:00:00'));
    const expected = gap(rows[1]);
    assert.equal(gap(rows[0]), expected);
    assert.equal(gap(rows[2]), expected);
    assert.equal(gap(rows[3]), expected);
    assert.equal(gap(rows[4]), expected);
});

test('text-default pictographs remain narrow unless emoji presentation is requested', () => {
    const titles = ['A', 'AB', '©', '®', '™', '☀', '©︎', '☀︎', '©️', '☀️'];
    const rows = renderBackgroundAgents(titles.map(ownerTitle => ({
        role: 'reviewer', ownerId: 'root', ownerTitle, state: 'idle', taskElapsedMs: 0,
    }))).split('\n').slice(2);
    const gap = (/** @type {string} */ row) => row.slice(row.indexOf('(root)') + '(root)'.length, row.indexOf('0:00:00'));
    for (const index of [2, 3, 4, 5, 6, 7]) assert.equal(gap(rows[index]), gap(rows[0]), titles[index]);
    for (const index of [8, 9]) assert.equal(gap(rows[index]), gap(rows[1]), titles[index]);
});

test('Unicode 17 fullwidth and halfwidth titles align by terminal width', () => {
    const titles = ['X　Y', 'ABCD', '！', '⺀', 'AB', 'ｦ', 'ﾡ', 'A'];
    const rows = renderBackgroundAgents(titles.map(ownerTitle => ({
        role: 'reviewer', ownerId: 'root', ownerTitle, state: 'idle', taskElapsedMs: 0,
    }))).split('\n').slice(2);
    const gap = (/** @type {string} */ row) => row.slice(row.indexOf('(root)') + '(root)'.length, row.indexOf('0:00:00'));
    assert.equal(gap(rows[0]), gap(rows[1]));
    assert.equal(gap(rows[2]), gap(rows[4]));
    assert.equal(gap(rows[3]), gap(rows[4]));
    assert.equal(gap(rows[5]), gap(rows[7]));
    assert.equal(gap(rows[6]), gap(rows[7]));
});

test('untrusted titles cannot emit terminal controls while missing titles retain gray N/A', () => {
    const rows = renderBackgroundAgents([
        {role: 'reviewer', ownerId: 'root-unsafe', ownerTitle: 'Before\u001b[2J\u001b[31mAfter\u001b[0m\u0007\u202e', state: 'running', taskElapsedMs: 0},
        {role: 'reviewer', ownerId: 'root-missing', ownerTitle: null, state: 'idle', taskElapsedMs: 0},
    ]).split('\n').slice(2);
    assert.equal(stripVTControlCharacters(rows[0]), rows[0]);
    assert.doesNotMatch(rows[0], /[\p{Cc}\p{Bidi_Control}]/u);
    assert.match(rows[0], /BeforeAfter\\u202e/u);
    assert.match(rows[0], /root-unsafe/u);
    assert.match(rows[1], /\u001b\[90mN\/A\u001b\[0m \(root-missing\)/u);
});
