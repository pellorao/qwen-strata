import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import test from 'node:test';

import {createTemporaryDirectory} from '../helpers/cleanup.mjs';
import {
    loadReleaseValidationConfiguration,
    renderVmwareCompatibilityStdout,
    validateReleaseValidationConfiguration,
} from '../../lib/release/release-validation-config.mjs';
import {
    listPreTagArchiveKinds,
    resolveReleaseValidationRegistry,
    resolveReleaseValidationStep,
} from '../../lib/release/release-validation-registry.mjs';

const configuration = () => ({
    initializationIssueScenario: 'scenarios/ubuntu/fresh-agent-assisted',
    prepareBundles: {hostCommandTimeoutMs: 123_456},
    repositories: {
        agentAssisted: {
            commit: 'a'.repeat(40),
            url: 'ssh://git@example.invalid/team/agent-assisted.git',
        },
        plain: {
            commit: 'b'.repeat(40),
            url: 'ssh://git@example.invalid/team/plain.git',
        },
        sourceCheckout: {url: 'ssh://git@example.invalid/team/arw.git'},
    },
    vmware: {
        hardPowerOffCompatibility: {
            exitCode: 7,
            stderr: '',
            stdoutTemplate: 'not powered on: {machineLocation}\n',
            vmrunVersion: 'vmrun test version',
        },
        softPowerOffTimeoutMs: {
            Alpine: 1_000,
            Ubuntu: 2_000,
            'Windows 11': 3_000,
        },
    },
});

test('fresh post-init Registry preserves exact finding order and retained Code Map paths', () => {
    const paths = [
        'src/client/README.md',
        'src/client/confirm/README.md',
        'src/client/event/README.md',
        'src/client/flow/README.md',
        'src/client/logging/README.md',
        'src/client/message-collection/README.md',
        'src/client/message/README.md',
        'src/client/oasis-context/README.md',
        'src/client/pages/README.md',
        'src/client/query/README.md',
        'src/client/router/README.md',
        'src/client/script/README.md',
        'src/client/test/README.md',
        'src/client/test/common/README.md',
        'src/client/test/setup/README.md',
        'src/client/theme/README.md',
        'src/server/README.md',
        'src/server/locale/README.md',
        'src/server/logging/README.md',
        'src/server/logging/performance-logger/README.md',
        'src/server/query/README.md',
        'src/server/test/README.md',
        'src/server/test/common/README.md',
        'src/server/theme/README.md',
        'src/server/theme/component/README.md',
        'src/server/theme/library/README.md',
        'src/server/theme/page/README.md',
        'src/server/theme/theme/README.md',
        'src/server/theme/variable/README.md',
        'src/server/ui-component/README.md',
        'src/server/utils/README.md',
        'src/server/validation/README.md',
    ];
    const init = resolveReleaseValidationStep({
        machineKey: 'Ubuntu',
        scenarioId: 'scenarios/ubuntu/fresh-agent-assisted',
        stepId: '002-init',
    }).step;
    if (init.mechanicalParameters === null) assert.fail('Expected init mechanical parameters.');
    assert.deepEqual(init.mechanicalParameters.expectedVerificationFindings,
        [...paths].sort((left, right) => left.localeCompare(right, 'en'))
            .map(path => ({code: 'ordinary-readme-at-code-map-path', path})));
    const remove = resolveReleaseValidationStep({
        machineKey: 'Ubuntu',
        scenarioId: 'scenarios/ubuntu/fresh-agent-assisted',
        stepId: '007-workflow-remove',
    }).step;
    if (remove.mechanicalParameters === null) assert.fail('Expected remove mechanical parameters.');
    assert.deepEqual(remove.mechanicalParameters.retainedPaths, paths);
    const initializedRemove = resolveReleaseValidationStep({
        machineKey: 'Ubuntu',
        scenarioId: 'scenarios/ubuntu/agent-assisted',
        stepId: '007-workflow-remove',
    }).step;
    if (initializedRemove.mechanicalParameters === null) assert.fail('Expected initialized remove mechanical parameters.');
    assert.deepEqual(initializedRemove.mechanicalParameters.retainedPaths, []);
});

test('release validation configuration accepts the exact closed shape and freezes current values', () => {
    const result = validateReleaseValidationConfiguration(configuration());

    assert.equal(result.status, 'succeeded');
    assert.equal(Object.isFrozen(result.value), true);
    assert.equal(Object.isFrozen(result.value.repositories.plain), true);
    assert.equal(Object.isFrozen(result.value.vmware.softPowerOffTimeoutMs), true);
    assert.equal(renderVmwareCompatibilityStdout({
        configuration: result.value,
        machineLocation: 'C:/VMs/example.vmx',
    }), 'not powered on: C:/VMs/example.vmx\n');
});

test('release validation configuration rejects extra fields and each invalid owned value class', () => {
    const cases = [
        {...configuration(), version: 1},
        {...configuration(), repositories: {
            ...configuration().repositories,
            agentAssisted: {...configuration().repositories.agentAssisted, commit: ''},
        }},
        {...configuration(), repositories: {...configuration().repositories, sourceCheckout: {url: 'https://example.invalid/arw.git'}}},
        {...configuration(), prepareBundles: {hostCommandTimeoutMs: 0}},
        {...configuration(), vmware: {...configuration().vmware, softPowerOffTimeoutMs: {Ubuntu: 1}}},
    ];

    for (const value of cases) assert.equal(validateReleaseValidationConfiguration(value).status, 'blocked');
});

test('release validation Registry resolves only the registered applicable initialization issue scenario', () => {
    const resolved = resolveReleaseValidationRegistry('scenarios/ubuntu/fresh-agent-assisted');
    assert.equal(resolved.status, 'succeeded');
    if (resolved.status !== 'succeeded' || !('scenarios' in resolved) || !('initializationIssue' in resolved)) {
        assert.fail('Expected resolved release validation Registry.');
    }
    assert.deepEqual(resolved.initializationIssue, {
        scenarioId: 'scenarios/ubuntu/fresh-agent-assisted',
        stepId: '003-complete-initialization-issue',
    });
    assert.equal(Object.isFrozen(resolved.scenarios), true);

    const fresh = resolved.scenarios.find(entry => entry.archiveKind === 'scenarios/ubuntu/fresh-agent-assisted');
    if (fresh === undefined) assert.fail('Expected fresh agent-assisted scenario.');
    assert.equal(fresh.phase, 'post-init');
    assert.equal(listPreTagArchiveKinds().includes(fresh.archiveKind), false);
    assert.deepEqual(fresh.prerequisites, [
        'candidate-bundle',
        'plain-target-bundle',
        'recommended-node',
        'shared-snapshot',
        'isolated-installation-home',
        'isolated-target-repository',
    ]);
    assert.deepEqual(fresh.steps.map(step => step.stepId), [
        '001-install',
        '002-init',
        '003-complete-initialization-issue',
        '004-workflow-update',
        '005-workflow-verify',
        '006-code-map-verify',
        '007-workflow-remove',
        '008-reinit',
        '009-final-workflow-verify',
        '010-final-code-map-verify',
        '011-uninstall',
    ]);

    for (const scenarioId of [
        'scenarios/windows/agent-assisted',
        'scenarios/ubuntu/agent-assisted',
        'scenarios/alpine/agent-assisted',
    ]) {
        /** @type {{steps: readonly {stepId: string}[]} | undefined} */
        const initializedScenario = resolved.scenarios.find(entry => entry.archiveKind === scenarioId);
        if (initializedScenario === undefined) assert.fail('Expected initialized agent-assisted scenario.');
        assert.equal(initializedScenario.steps.some(step => step.stepId.endsWith('-init')
            || step.stepId.endsWith('-complete-initialization-issue')), false);
        assert.equal(resolveReleaseValidationRegistry(scenarioId).diagnostics[0].code,
            'initialization-issue-scenario-inapplicable');
    }

    assert.equal(resolveReleaseValidationRegistry('missing').diagnostics[0].code,
        'initialization-issue-scenario-unregistered');
});

test('release validation configuration loads through the scoped Filesystem and shared JSON boundary', async t => {
    const repositoryRoot = await createTemporaryDirectory(t, 'arw-release-config-');
    await writeFile(join(repositoryRoot, 'release-validation.json'), `${JSON.stringify(configuration())}\n`, 'utf8');

    const result = await loadReleaseValidationConfiguration({repositoryRoot});
    assert.equal(result.status, 'succeeded');
    if (result.status !== 'succeeded' || !('value' in result)) assert.fail('Expected valid release configuration.');
    assert.equal(result.value.repositories.plain.commit, 'b'.repeat(40));
});
