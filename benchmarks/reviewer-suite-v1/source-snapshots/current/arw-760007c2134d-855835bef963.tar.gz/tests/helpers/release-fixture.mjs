import {readFile} from 'node:fs/promises';
import {join} from 'node:path';

import {parsePackageIdentity} from '../../lib/arw-common/identity.mjs';

/** @typedef {{sourceDirectory: string, tag: string}} VerifiedReleaseFixtureInput */
/** @typedef {{arwVersion: string, diagnostics: readonly unknown[], sourceDirectory: string, status: 'succeeded'}} VerifiedReleaseFixture */

/**
 * 构造 Installation 测试消费的完整 Verified Release fixture.
 */
/** @param {VerifiedReleaseFixtureInput} input @returns {Promise<VerifiedReleaseFixture>} */
export const createVerifiedReleaseFixture = async ({sourceDirectory, tag}) => {
    const identity = parsePackageIdentity(await readFile(join(sourceDirectory, 'package.json')), 'package.json');

    if (tag !== identity.version) throw new Error('Verified Release fixture tag does not match package.json version.');
    return {
        arwVersion: identity.version,
        diagnostics: [],
        sourceDirectory,
        status: 'succeeded',
    };
};
