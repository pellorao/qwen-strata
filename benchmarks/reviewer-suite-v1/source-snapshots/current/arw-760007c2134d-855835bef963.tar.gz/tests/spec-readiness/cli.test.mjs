import assert from 'node:assert/strict';
import {mkdir, readFile, rm, writeFile} from 'node:fs/promises';
import {dirname, join} from 'node:path';
import test from 'node:test';

import {createRepository, run, writeArtifact, writeIssue} from '../helpers/arw-cli.mjs';

test('spec readiness prepare accepts JSON stdin and emits a minimal reviewer request', async t => {
    const repository = await createRepository(t);
    const spec = '# Test spec\n\n## Module Design\n\nNot required: No module boundary changes.\n';
    const role = '# Reviewer\n\n## Responsibility\n\nReview.\n';
    const issue = '# Implement workflow\n\nStatus: ready-for-agent\n\n## What to build\n\nImplement.\n\n## Spec Requirement\n\nGoverning requirements:\n\n- `.scratch/0001-workflow/spec.md#module-design`\n\n## Acceptance criteria\n\n- [ ] Complete.\n\n## Blocked by\n\n- None\n';
    await writeArtifact(repository.root, '0001-workflow', 'spec.md', spec);
    await writeIssue(repository.root, '0001-workflow', '01-implement.md', issue);
    await mkdir(join(repository.root, 'docs', 'agents', 'roles'), {recursive: true});
    await writeFile(join(repository.root, 'docs', 'agents', 'roles', 'spec-readiness-reviewer.md'), role, 'utf8');

    const draftPath = join(repository.root, '.tmp', 'codex', 'test-session', '0001_01', 'spec-readiness', 'reviewer-drafts', 'draft.jsonl');
    const prepared = await run(['spec-readiness', 'prepare', '--issue', 'issue:0001:01'], repository, {
        specReadinessDependencies: {
            platformAdapter: {getCurrentAgentIdentity: () => ({platform: 'codex', sessionId: 'test-session'})},
        },
        stdin: JSON.stringify({draftPath, inputs: [{filePath: '.scratch/0001-workflow/spec.md', role: 'governing-spec'}]}),
    });

    assert.equal(prepared.result, 0, JSON.stringify(prepared.events));
    assert.match(prepared.events[0].message, /[\\/]requests[\\/]request-[0-9a-f-]+\.json$/);
    const request = JSON.parse(await readFile(prepared.events[0].message, 'utf8'));
    assert.equal(request.issueId, 'issue:0001:01');
    assert.equal(request.draftPath, draftPath);
    assert.equal(request.inputs.length, 1);
    assert.equal(request.reviewerRole.id, 'spec-readiness-reviewer');
    assert.equal(request.reviewerRole.filePath, 'docs/agents/roles/spec-readiness-reviewer.md');
    assert.match(request.reviewerRole.sha256, /^[0-9a-f]{64}$/);
    assert.equal(request.subject.filePath, '.scratch/0001-workflow/issues/01-implement.md');
    assert.match(request.subject.sha256, /^[0-9a-f]{64}$/);
});

test('spec readiness prepare accepts the shared JSON schema from an input file', async t => {
    const repository = await createRepository(t);
    const spec = '# Test spec\n\n## Module Design\n\nNot required: No module boundary changes.\n';
    const role = '# Reviewer\n\n## Responsibility\n\nReview.\n';
    const issue = '# Implement workflow\n\nStatus: ready-for-agent\n\n## What to build\n\nImplement.\n\n## Spec Requirement\n\nGoverning requirements:\n\n- `.scratch/0001-workflow/spec.md#module-design`\n\n## Acceptance criteria\n\n- [ ] Complete.\n\n## Blocked by\n\n- None\n';
    await writeArtifact(repository.root, '0001-workflow', 'spec.md', spec);
    await writeIssue(repository.root, '0001-workflow', '01-implement.md', issue);
    await mkdir(join(repository.root, 'docs', 'agents', 'roles'), {recursive: true});
    await writeFile(join(repository.root, 'docs', 'agents', 'roles', 'spec-readiness-reviewer.md'), role, 'utf8');
    const inputPath = join(repository.root, '.tmp', 'codex', 'test-session', '0001_01', 'spec-readiness', 'prepare-input.json');
    await mkdir(dirname(inputPath), {recursive: true});
    const draftPath = join(repository.root, '.tmp', 'codex', 'test-session', '0001_01', 'spec-readiness', 'reviewer-drafts', 'draft.jsonl');
    await writeFile(inputPath, JSON.stringify({draftPath, inputs: [{filePath: '.scratch/0001-workflow/spec.md', role: 'governing-spec'}]}), 'utf8');

    const prepared = await run(['spec-readiness', 'prepare', '--issue', 'issue:0001:01', '--input', inputPath], repository, {
        specReadinessDependencies: {
            platformAdapter: {getCurrentAgentIdentity: () => ({platform: 'codex', sessionId: 'test-session'})},
        },
        stdin: 'not valid JSON',
    });

    assert.equal(prepared.result, 0);
    assert.match(prepared.events[0].message, /[\\/]requests[\\/]request-[0-9a-f-]+\.json$/);
    const request = JSON.parse(await readFile(prepared.events[0].message, 'utf8'));
    assert.equal(request.draftPath, draftPath);
    assert.equal(request.inputs.length, 1);
    assert.equal(request.reviewerRole.id, 'spec-readiness-reviewer');
});

test('spec readiness rejects an issue in duplicate effort identities', async t => {
    const repository = await createRepository(t);
    const spec = '# Test spec\n\n## Module Design\n\nNot required: No module boundary changes.\n';
    const issue = '# Implement workflow\n\nStatus: ready-for-agent\n\n## What to build\n\nImplement.\n\n## Spec Requirement\n\nGoverning requirements:\n\n- `.scratch/0001-first/spec.md#module-design`\n\n## Acceptance criteria\n\n- [ ] Complete.\n\n## Blocked by\n\n- None\n';
    await writeArtifact(repository.root, '0001-first', 'spec.md', spec);
    await writeIssue(repository.root, '0001-first', '01-implement.md', issue);
    await writeArtifact(repository.root, '0001-second', 'spec.md', spec);
    await mkdir(join(repository.root, 'docs', 'agents', 'roles'), {recursive: true});
    await writeFile(join(repository.root, 'docs', 'agents', 'roles', 'spec-readiness-reviewer.md'), '# Reviewer\n', 'utf8');
    const draftPath = join(repository.root, '.tmp', 'codex', 'test-session', '0001_01', 'spec-readiness', 'reviewer-drafts', 'draft.jsonl');

    const prepared = await run(['spec-readiness', 'prepare', '--issue', 'issue:0001:01'], repository, {
        specReadinessDependencies: {
            platformAdapter: {getCurrentAgentIdentity: () => ({platform: 'codex', sessionId: 'test-session'})},
        },
        stdin: JSON.stringify({draftPath, inputs: [{filePath: '.scratch/0001-first/spec.md', role: 'governing-spec'}]}),
    });

    assert.equal(prepared.result, 1);
    assert.match(prepared.events[0].message, /Implementation issue not found: issue:0001:01/);
});

test('spec readiness generate consumes the bound findings-only JSONL draft', async t => {
    const repository = await createRepository(t);
    const spec = '# Test spec\n\n## Module Design\n\nNot required: Runtime modules are unchanged.\n';
    const issue = '# Implement\n\nStatus: ready-for-agent\n\n## What to build\n\nImplement.\n\n## Spec Requirement\n\nGoverning requirements:\n\n- `.scratch/0001-workflow/spec.md#module-design`\n\n## Acceptance criteria\n\n- [ ] Complete.\n\n## Blocked by\n\n- None\n';
    await writeArtifact(repository.root, '0001-workflow', 'spec.md', spec);
    await writeIssue(repository.root, '0001-workflow', '01-implement.md', issue);
    await mkdir(join(repository.root, 'docs', 'agents', 'roles'), {recursive: true});
    await writeFile(join(repository.root, 'docs', 'agents', 'roles', 'spec-readiness-reviewer.md'), '# Reviewer\n', 'utf8');
    const dependencies = {platformAdapter: {getCurrentAgentIdentity: () => ({platform: 'codex', sessionId: 'test-session'})}};
    const draftPath = join(repository.root, '.tmp', 'codex', 'test-session', '0001_01', 'spec-readiness', 'reviewer-drafts', 'draft.jsonl');
    const prepared = await run(['spec-readiness', 'prepare', '--issue', 'issue:0001:01'], repository, {
        specReadinessDependencies: dependencies,
        stdin: JSON.stringify({draftPath, inputs: [{filePath: '.scratch/0001-workflow/spec.md', role: 'governing-spec'}]}),
    });
    assert.equal(prepared.result, 0);
    await writeFile(draftPath, `${JSON.stringify({status: 'no-findings'})}\n`, 'utf8');
    const generated = await run(['spec-readiness', 'generate', '--issue', 'issue:0001:01', '--input', draftPath], repository, {
        specReadinessDependencies: dependencies,
        stdin: 'not selected',
    });

    assert.equal(generated.result, 0);
    const generatedPath = generated.events[0].message;
    assert.match(generatedPath, /[\\/]artifacts[\\/]artifact-[0-9a-f-]+\.json$/);
    const recordPath = join(repository.root, '.scratch', '0001-workflow', 'issues', '01.spec-readiness.json');
    await assert.rejects(readFile(recordPath, 'utf8'), {code: 'ENOENT'});
    const promoted = await run(['spec-readiness', 'promote', '--input', generatedPath], repository, {specReadinessDependencies: dependencies});
    assert.equal(promoted.result, 0);
    assert.equal(promoted.events[0].message, 'Wrote .scratch/0001-workflow/issues/01.spec-readiness.json with result: satisfied.');
    const record = JSON.parse(await readFile(recordPath, 'utf8'));
    assert.equal(record.schemaVersion, 6);
});

test('spec readiness CLI covers immutable request, generate, promote, verify, and exception lifecycle', async t => {
    const repository = await createRepository(t);
    const spec = '# Test spec\n\n## Module Design\n\n### Modules\n\nOwn behavior.\n\n### Interfaces\n\nInput and output.\n\n### Seams and Adapters\n\nVariation.\n\n### Dependencies and Data Flow\n\nFlow.\n\n### Design Rationale\n\nTradeoff.\n\n### ADR Evaluation\n\nNone.\n';
    const normalIssue = '# Implement workflow\n\nStatus: ready-for-agent\n\n## What to build\n\nImplement.\n\n## Spec Requirement\n\nGoverning requirements:\n\n- `.scratch/0001-workflow/spec.md#module-design`\n\n## Acceptance criteria\n\n- [ ] Complete.\n\n## Blocked by\n\n- None\n';
    const dependencies = {platformAdapter: {getCurrentAgentIdentity: () => ({platform: 'codex', sessionId: 'lifecycle-test'})}};
    const recordPath = join(repository.root, '.scratch', '0001-workflow', 'issues', '01.spec-readiness.json');
    const workspace = join(repository.root, '.tmp', 'codex', 'lifecycle-test', '0001_01', 'spec-readiness');
    await writeArtifact(repository.root, '0001-workflow', 'spec.md', spec);
    await writeIssue(repository.root, '0001-workflow', '01-implement.md', normalIssue);
    await writeIssue(repository.root, '0001-workflow', '02-same-scope.md', normalIssue.replace('#module-design', '#interfaces'));
    await mkdir(join(repository.root, 'docs', 'agents', 'roles'), {recursive: true});
    await writeFile(join(repository.root, 'docs', 'agents', 'roles', 'spec-readiness-reviewer.md'), '# Reviewer\n', 'utf8');

    const draftPath = join(workspace, 'reviewer-drafts', 'draft.jsonl');
    const prepared = await run(['spec-readiness', 'prepare', '--issue', 'issue:0001:01'], repository, {
        specReadinessDependencies: dependencies,
        stdin: JSON.stringify({draftPath, inputs: [
            {filePath: '.scratch/0001-workflow/spec.md', role: 'governing-spec'},
            {filePath: '.scratch/0001-workflow/spec.md', role: 'governing-spec'},
        ]}),
    });
    assert.equal(prepared.result, 0);
    const missingInput = await run(['spec-readiness', 'generate', '--issue', 'issue:0001:01'], repository, {specReadinessDependencies: dependencies});
    assert.equal(missingInput.result, 2);

    await writeFile(draftPath, `${JSON.stringify({status: 'no-findings'})}\n`, 'utf8');
    const generated = await run(['spec-readiness', 'generate', '--issue', 'issue:0001:01', '--input', draftPath], repository, {
        specReadinessDependencies: dependencies,
    });
    assert.equal(generated.result, 0);
    const generatedPath = generated.events[0].message;
    assert.equal((await run(['spec-readiness', 'verify', '--issue', 'issue:0001:01'], repository)).result, 1);
    assert.equal((await run(['spec-readiness', 'promote', '--input', generatedPath], repository, {specReadinessDependencies: dependencies})).result, 0);
    const before = await readFile(recordPath, 'utf8');
    await writeFile(join(repository.root, '.scratch', '0001-workflow', 'issues', '02.spec-readiness.json'), before, 'utf8');
    const verified = await run(['spec-readiness', 'verify', '--issue', 'issue:0001:02'], repository);
    assert.equal(verified.result, 1);
    assert.match(verified.events[0].message, /Spec Readiness record does not match the issue/);

    await writeFile(draftPath, '{not valid JSON}\n', 'utf8');
    const rejectedInvalidJsonl = await run(['spec-readiness', 'generate', '--issue', 'issue:0001:01', '--input', draftPath], repository, {
        specReadinessDependencies: dependencies,
    });
    assert.equal(rejectedInvalidJsonl.result, 1);
    assert.equal(await readFile(recordPath, 'utf8'), before);
    await writeFile(join(repository.root, '.scratch', '0001-workflow', 'spec.md'), `${spec}\nChanged.\n`, 'utf8');
    const stale = await run(['spec-readiness', 'verify', '--issue', 'issue:0001:01'], repository);
    assert.equal(stale.result, 1);
    assert.match(stale.events[0].message, /Stale Spec Readiness Input/);

    await writeIssue(repository.root, '0001-workflow', '01-implement.md', normalIssue.replace('Governing requirements:\n\n- `.scratch/0001-workflow/spec.md#module-design`', 'Not required'));
    const exceptionDraftPath = join(workspace, 'exception.json');
    await writeFile(exceptionDraftPath, JSON.stringify({exception: {confirmedAt: '2026-08-04T12:34:56Z', reason: 'No governing design is required.'}}), 'utf8');
    const invalidatedException = await run(['spec-readiness', 'generate', '--issue', 'issue:0001:01', '--input', exceptionDraftPath], repository, {
        specReadinessDependencies: dependencies,
    });
    assert.equal(invalidatedException.result, 1);
    assert.match(invalidatedException.events[0].message, /exactly one implementation issue/);
    await rm(join(repository.root, '.scratch', '0001-workflow', 'issues', '02-same-scope.md'));
    const exception = await run(['spec-readiness', 'generate', '--issue', 'issue:0001:01', '--input', exceptionDraftPath], repository, {
        specReadinessDependencies: dependencies,
    });
    assert.equal(exception.result, 0);
    assert.equal((await run(['spec-readiness', 'promote', '--input', exception.events[0].message], repository, {specReadinessDependencies: dependencies})).result, 0);
    assert.equal((await run(['spec-readiness', 'verify', '--issue', 'issue:0001:01'], repository)).result, 0);
});

test('spec readiness JSON CLI maps findings and usage errors to global exits', async t => {
    const repository = await createRepository(t);
    const issue = '# Implement workflow\n\nStatus: ready-for-agent\n\n## What to build\n\nImplement.\n\n## Spec Requirement\n\nGoverning requirements:\n\n- `.scratch/0001-workflow/spec.md#module-design`\n\n## Acceptance criteria\n\n- [ ] Complete.\n\n## Blocked by\n\n- None\n';
    await writeIssue(repository.root, '0001-workflow', '01-implement.md', issue);
    const dependencies = {platformAdapter: {getCurrentAgentIdentity: () => ({platform: 'codex', sessionId: 'cli-test'})}};
    const finding = await run(['spec-readiness', 'prepare', '--issue', 'issue:0001:01'], repository, {specReadinessDependencies: dependencies, stdin: JSON.stringify({inputs: []})});
    const usageError = await run(['spec-readiness', 'prepare', '--effort', 'workflow'], repository);

    assert.equal(finding.result, 1);
    assert.ok(finding.events.every(event => event.channel === 'stderr'));
    assert.equal(usageError.result, 2);
    assert.ok(usageError.events.every(event => event.channel === 'stderr'));
});
