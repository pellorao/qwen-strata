import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import test from 'node:test';

import {
    createClaudeCodePlatformAdapter,
    createCodexPlatformAdapter,
} from '../../lib/arw-common/platform-adapter.mjs';
import {buildWorkflowDistribution} from '../../lib/workflow-distribution/workflow-distribution.mjs';

const distributionDirectory = resolve(process.cwd(), 'distribution');

test('Workflow Distribution projects no native Reviewer configuration seeds', async () => {
    const distribution = await buildWorkflowDistribution({distributionDirectory});
    assert.equal(distribution.status, 'succeeded', JSON.stringify(distribution.diagnostics));
    if (distribution.status !== 'succeeded') throw new Error('Expected a built Workflow Distribution.');
    assert.deepEqual(distribution.payload.filter(entry => entry.path.startsWith('projections/agent-role-seeds/')), []);

    const adapters = {
        'claude-code': createClaudeCodePlatformAdapter(),
        codex: createCodexPlatformAdapter(),
    };
    for (const platform of /** @type {const} */ (['claude-code', 'codex'])) {
        const projected = adapters[platform].evaluate({
            payload: distribution.payload,
            platform,
            profile: {codeMaps: {excludes: [], includes: [], roots: []}, platforms: [platform]},
            projectionConfig: distribution.projectionConfig,
            seedTargets: {},
        });
        assert.equal(projected.status, 'succeeded', JSON.stringify(projected.diagnostics));
        if (projected.status !== 'succeeded') throw new Error(`Expected a successful ${platform} projection.`);
        assert.deepEqual(projected.repositoryOwnedSeeds, []);
    }
});
