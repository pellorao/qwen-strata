import assert from 'node:assert/strict';
import test from 'node:test';

import {
    cloneJsonValue,
    deleteJsonPath,
    digestJson,
    isJsonObject,
    jsonSemanticallyEqual,
    parseJson,
    readJsonPath,
    serializeJson,
    writeJson,
    writeJsonPath,
} from '../../lib/common/json.mjs';

test('isJsonObject recognizes shallow objects without claiming nested JSON validity', () => {
    const nonJsonObject = {nested: undefined};
    assert.equal(isJsonObject(nonJsonObject), true);
    assert.equal(serializeJson(nonJsonObject).status, 'blocked');
    assert.equal(isJsonObject([]), false);
    assert.equal(isJsonObject(null), false);
});

test('parseJson accepts strings, exact UTF-8 bytes, and scoped files without newline normalization', async () => {
    const crlf = Buffer.from('{\r\n  "value": true\r\n}\r\n', 'utf8');
    assert.deepEqual(await parseJson(crlf), {
        diagnostics: [],
        status: 'succeeded',
        value: {value: true},
    });
    assert.deepEqual(await parseJson({
        filesystem: {read: async () => ({bytes: crlf, diagnostics: [], status: 'succeeded'})},
        path: 'value.json',
    }), {
        diagnostics: [],
        status: 'succeeded',
        value: {value: true},
    });
    assert.equal((await parseJson(Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), crlf]))).status, 'blocked');
    assert.equal((await parseJson(Buffer.from([0xff]))).status, 'blocked');
    assert.equal((await parseJson('{')).status, 'blocked');
});

test('cloneJsonValue returns an independent JSON value', () => {
    const source = {array: [{value: 1}], object: {enabled: true}};
    const cloned = cloneJsonValue(source);

    assert.deepEqual(cloned, source);
    assert.notEqual(cloned, source);
    assert.notEqual(cloned.array, source.array);
    assert.notEqual(cloned.array[0], source.array[0]);
    assert.notEqual(cloned.object, source.object);
    assert.throws(() => cloneJsonValue(undefined), TypeError);
    assert.throws(() => cloneJsonValue({value: Number.NaN}), TypeError);
});

test('readJsonPath distinguishes missing values and returns independent copies', () => {
    const source = {parent: {leaf: {value: 1}}};
    const present = readJsonPath(source, ['parent', 'leaf']);

    assert.deepEqual(present, {
        diagnostics: [],
        present: true,
        status: 'succeeded',
        value: {value: 1},
    });
    assert.notEqual(present.value, source.parent.leaf);
    assert.deepEqual(readJsonPath(source, ['parent', 'missing']), {
        diagnostics: [],
        present: false,
        status: 'succeeded',
    });
    const blocked = readJsonPath({parent: []}, ['parent', 'leaf']);
    assert.equal(blocked.status, 'blocked');
    assert.equal(blocked.diagnostics[0].code, 'json-path-ancestor-not-object');
    assert.equal(blocked.diagnostics[0].path, 'parent');
});

test('writeJsonPath creates object ancestors without sharing source or nextValue identities', () => {
    const source = {keep: {value: 1}};
    const nextValue = {nested: [1, 2]};
    const result = writeJsonPath(source, ['created', 'leaf'], nextValue);

    assert.deepEqual(result, {
        diagnostics: [],
        status: 'succeeded',
        value: {keep: {value: 1}, created: {leaf: {nested: [1, 2]}}},
    });
    assert.deepEqual(source, {keep: {value: 1}});
    assert.notEqual(result.value, source);
    assert.notEqual(result.value.keep, source.keep);
    assert.notEqual(result.value.created.leaf, nextValue);
    assert.notEqual(result.value.created.leaf.nested, nextValue.nested);
    nextValue.nested.push(3);
    assert.deepEqual(result.value.created.leaf.nested, [1, 2]);

    const blocked = writeJsonPath({parent: 1}, ['parent', 'leaf'], true);
    assert.equal(blocked.status, 'blocked');
    assert.equal(Object.hasOwn(blocked, 'value'), false);
});

test('deleteJsonPath is idempotent and preserves empty parents', () => {
    const source = {parent: {leaf: 1}, keep: true};
    assert.deepEqual(deleteJsonPath(source, ['parent', 'leaf']), {
        diagnostics: [],
        removed: true,
        status: 'succeeded',
        value: {parent: {}, keep: true},
    });
    assert.deepEqual(source, {parent: {leaf: 1}, keep: true});
    assert.deepEqual(deleteJsonPath(source, ['parent', 'missing']), {
        diagnostics: [],
        removed: false,
        status: 'succeeded',
        value: source,
    });
    const blocked = deleteJsonPath({parent: []}, ['parent', 'leaf']);
    assert.equal(blocked.status, 'blocked');
    assert.equal(Object.hasOwn(blocked, 'value'), false);

    for (const invoke of [
        () => readJsonPath({}, []),
        () => deleteJsonPath({}, [1]),
        () => writeJsonPath({}, ['value'], undefined),
    ]) {
        assert.throws(invoke, TypeError);
    }
});

test('JSON path operations address an empty-string object key', () => {
    const source = {'': {leaf: 1}};
    assert.deepEqual(readJsonPath(source, ['', 'leaf']), {
        diagnostics: [],
        present: true,
        status: 'succeeded',
        value: 1,
    });
    assert.deepEqual(writeJsonPath(source, ['', 'leaf'], 2), {
        diagnostics: [],
        status: 'succeeded',
        value: {'': {leaf: 2}},
    });
    assert.deepEqual(deleteJsonPath(source, ['', 'leaf']), {
        diagnostics: [],
        removed: true,
        status: 'succeeded',
        value: {'': {}},
    });
    assert.deepEqual(source, {'': {leaf: 1}});
});

test('JSON path operations preserve __proto__ as an ordinary object key', () => {
    const source = JSON.parse('{"__proto__":{"leaf":1}}');
    const written = writeJsonPath({}, ['__proto__', 'leaf'], 2);

    assert.deepEqual(readJsonPath(source, ['__proto__', 'leaf']), {
        diagnostics: [],
        present: true,
        status: 'succeeded',
        value: 1,
    });
    assert.deepEqual(written, {
        diagnostics: [],
        status: 'succeeded',
        value: JSON.parse('{"__proto__":{"leaf":2}}'),
    });
    if (written.status !== 'succeeded' || written.value === null || typeof written.value !== 'object') {
        throw new Error('JSON path write did not return an object value.');
    }
    assert.equal(Object.getPrototypeOf(written.value), Object.prototype);
    assert.equal(Object.hasOwn(written.value, '__proto__'), true);
    assert.deepEqual(deleteJsonPath(source, ['__proto__']), {
        diagnostics: [],
        removed: true,
        status: 'succeeded',
        value: {},
    });
});

test('JSON Module preserves default field order while semantic operations ignore object key order', async () => {
    const value = {z: 1, a: {y: 2, x: 3}};
    const preserved = serializeJson(value);
    const sorted = serializeJson(value, {sortKeys: true});
    const compact = serializeJson(value, {format: 'compact'});
    const compactSorted = serializeJson(value, {format: 'compact', sortKeys: true});
    assert.equal(preserved.status, 'succeeded');
    if (preserved.status !== 'succeeded'
        || sorted.status !== 'succeeded'
        || compact.status !== 'succeeded'
        || compactSorted.status !== 'succeeded') assert.fail('Valid JSON serialization must succeed.');
    assert.equal(preserved.bytes.toString('utf8'), '{\n  "z": 1,\n  "a": {\n    "y": 2,\n    "x": 3\n  }\n}\n');
    assert.equal(sorted.bytes.toString('utf8'), '{\n  "a": {\n    "x": 3,\n    "y": 2\n  },\n  "z": 1\n}\n');
    assert.equal(compact.bytes.toString('utf8'), '{"z":1,"a":{"y":2,"x":3}}');
    assert.equal(compactSorted.bytes.toString('utf8'), '{"a":{"x":3,"y":2},"z":1}');
    assert.equal(compact.bytes.includes(0x0a), false);
    assert.deepEqual(await parseJson(sorted.bytes.toString('utf8')), {diagnostics: [], status: 'succeeded', value: {a: {x: 3, y: 2}, z: 1}});
    assert.equal(jsonSemanticallyEqual(value, {a: {x: 3, y: 2}, z: 1}), true);
    assert.equal(digestJson(value), digestJson({a: {x: 3, y: 2}, z: 1}));
    assert.equal(serializeJson({value: Number.NaN}).status, 'blocked');
    assert.throws(() => serializeJson(value, /** @type {never} */ ({format: 'unknown'})), TypeError);

    /** @type {Buffer | undefined} */
    let writtenBytes;
    const written = await writeJson({
        filesystem: {
            async write({bytes}) {
                writtenBytes = bytes;
                return {status: 'succeeded'};
            },
        },
        path: 'record.json',
        value,
    }, {format: 'compact'});
    assert.equal(written.status, 'succeeded');
    assert.equal(writtenBytes?.toString('utf8'), '{"z":1,"a":{"y":2,"x":3}}');
});
