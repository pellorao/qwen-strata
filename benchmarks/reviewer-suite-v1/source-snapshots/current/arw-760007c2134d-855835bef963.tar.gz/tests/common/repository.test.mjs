import assert from 'node:assert/strict';
import {join, resolve} from 'node:path';
import test from 'node:test';

import {createNodeRepositoryObserver, resolveRepository} from '../../lib/common/repository.mjs';

test('Repository Module returns one canonical identity and a bound safe path resolver', async () => {
    const root = resolve('repository-root');
    const result = await resolveRepository({
        observer: {
            canonicalize: async path => path,
            discover: async () => ({kind: 'observed', root}),
        },
        startDirectory: join(root, 'nested'),
    });

    assert.equal(result.status, 'succeeded');
    assert.equal(result.repository.identity, root);
    assert.equal(result.repository.resolvePath('docs/spec.md').status, 'succeeded');
    assert.deepEqual(result.repository.resolvePath('../outside'), {
        diagnostics: [{
            code: 'repository-path-escape',
            message: 'The path escapes the Repository root.',
            path: '../outside',
        }],
        status: 'blocked',
    });
    const normalized = result.repository.resolvePath('draft/../docs/spec.md');
    assert.equal(normalized.status, 'succeeded');
    if (normalized.status !== 'succeeded') assert.fail('Repository path normalization must succeed.');
    assert.equal(normalized.path, 'docs/spec.md');
});

test('Repository Module distinguishes a missing working tree from other Git discovery failures', async () => {
    /** @type {Array<{argv: string[], environment?: NodeJS.ProcessEnv}>} */
    const requests = [];
    for (const stderr of [
        'fatal: not a git repository (or any of the parent directories): .git\n',
        'fatal: not a git repository (or any parent up to mount point /)\nStopping at filesystem boundary (GIT_DISCOVERY_ACROSS_FILESYSTEM not set).\n',
    ]) {
        const missing = await resolveRepository({
            observer: createNodeRepositoryObserver({
                git: {
                    async run(request) {
                        requests.push(request);
                        return {code: 128, failure: null, stderr, stdout: Buffer.alloc(0)};
                    },
                },
            }),
            startDirectory: resolve('outside'),
        });
        assert.equal(missing.status, 'blocked');
        assert.deepEqual(missing.diagnostics.map(entry => entry.code), ['repository-not-found']);
    }
    const firstRequest = requests[0];
    if (firstRequest === undefined) assert.fail('Repository discovery request must be recorded.');
    assert.deepEqual(firstRequest.argv, ['rev-parse', '--show-toplevel']);
    assert.equal(firstRequest.environment?.LC_ALL, 'C');

    const failed = await resolveRepository({
        observer: createNodeRepositoryObserver({
            git: {
                async run() {
                    return {
                        code: 128,
                        failure: null,
                        stderr: 'fatal: detected dubious ownership in repository at C:/repo\n',
                        stdout: Buffer.alloc(0),
                    };
                },
            },
        }),
        startDirectory: resolve('repository-root'),
    });
    assert.equal(failed.status, 'failed');
    assert.equal(failed.stage, 'repository-discovery');
    assert.deepEqual(failed.diagnostics.map(entry => entry.code), ['repository-observation-failed']);
});
