import assert from 'node:assert/strict';
import test from 'node:test';

import {parseMarkdownVisibleText} from '../../lib/common/markdown-visible-text.mjs';

const parse = (/** @type {import("buffer").WithImplicitCoercion<string>} */ text) => parseMarkdownVisibleText({
    bytes: Buffer.from(text, 'utf8'),
    path: 'docs/example.md',
});

test('Markdown Visible Text Module 提取可见自然语言并排除语法和代码', () => {
    const source = [
        '---',
        'title: Hidden frontmatter',
        '---',
        '# 说明 `hidden code`',
        '',
        '第一行 [ARW Artifact](https://example.invalid) 与 ![图片说明](image.png)',
        '第二行 **Main Agent**.',
        '',
        '> 引用文字',
        '',
        '| 列一 | 列二 |',
        '| --- | --- |',
        '| visible | `hidden cell` |',
        '| state | `exited | failed` |',
        '',
        '<!-- hidden comment -->',
        '<div class="hidden">HTML 正文</div>',
        '<https://example.invalid>',
        '<script>hidden script body</script>',
        '    hidden indented code',
        '```js',
        'hidden fenced code',
        '```',
        '',
    ].join('\n');

    const result = parse(source);

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), [
        '说明',
        '第一行 ARW Artifact 与 图片说明 第二行 Main Agent.',
        '引用文字',
        '列一',
        '列二',
        'visible',
        'state',
        'HTML 正文',
    ]);
    for (const flow of result.flows) assert.equal(flow.positions.length, Array.from(flow.text).length);
});

test('Markdown Visible Text Module 使用 Unicode code point column 并定位软换行', () => {
    const result = parse('# 😀名\n\n首行\n  次行\n');

    assert.deepEqual(result, {
        diagnostics: [],
        flows: [
            {
                kind: 'heading',
                positions: [
                    {column: 3, line: 1},
                    {column: 4, line: 1},
                ],
                text: '😀名',
            },
            {
                kind: 'body',
                positions: [
                    {column: 1, line: 3},
                    {column: 2, line: 3},
                    {column: 3, line: 4},
                    {column: 3, line: 4},
                    {column: 4, line: 4},
                ],
                text: '首行 次行',
            },
        ],
    });
});

test('Markdown Visible Text Module 把 Setext heading 与正文分开', () => {
    const result = parse('English title\n==============\n\n中文正文\n');

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(({kind, text}) => ({kind, text})), [
        {kind: 'heading', text: 'English title'},
        {kind: 'body', text: '中文正文'},
    ]);
});

test('Markdown Visible Text Module 允许 fenced code 在文档结尾结束并报告其他未闭合结构', () => {
    assert.deepEqual(parse('正文\n\n~~~js\nconst hidden = true;\n'), {
        diagnostics: [],
        flows: [{
            kind: 'body',
            positions: [
                {column: 1, line: 1},
                {column: 2, line: 1},
            ],
            text: '正文',
        }],
    });

    assert.deepEqual(parse('正文 `未闭合\n'), {
        diagnostics: [{code: 'malformed-markdown', column: 4, line: 1, path: 'docs/example.md'}],
        flows: [{
            kind: 'body',
            positions: [
                {column: 1, line: 1},
                {column: 2, line: 1},
            ],
            text: '正文',
        }],
    });
});

test('Markdown Visible Text Module 不把段落中 inline code 的 pipe 解释为表格', () => {
    assert.deepEqual(parse('普通 `accepted | rejected` 文字.\n'), {
        diagnostics: [],
        flows: [{
            kind: 'body',
            positions: [
                {column: 1, line: 1},
                {column: 2, line: 1},
                {column: 3, line: 1},
                {column: 26, line: 1},
                {column: 27, line: 1},
                {column: 28, line: 1},
            ],
            text: '普通 文字.',
        }],
    });
});

test('Markdown Visible Text Module 排除跨段落软换行的 inline code span', () => {
    assert.deepEqual(parse('前文 `第一行\n第二行` 后文\n'), {
        diagnostics: [],
        flows: [{
            kind: 'body',
            positions: [
                {column: 1, line: 1},
                {column: 2, line: 1},
                {column: 3, line: 1},
                {column: 6, line: 2},
                {column: 7, line: 2},
            ],
            text: '前文 后文',
        }],
    });
});

test('Markdown Visible Text Module 保留嵌套列表项并排除真正的缩进代码', () => {
    const result = parse('- parent\n    - Workflow Distribution\n\n    hidden code\n');

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), ['parent', 'Workflow Distribution']);
});

test('Markdown Visible Text Module 合并列表与引用中的软换行段落', () => {
    const result = parse([
        '- 列表 [Workflow',
        '  Distribution](https://example.invalid)',
        '',
        '> 引用 [Workflow',
        '> Distribution](https://example.invalid)',
        '',
    ].join('\n'));

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), [
        '列表 Workflow Distribution',
        '引用 Workflow Distribution',
    ]);
});

test('Markdown Visible Text Module 合并列表与引用中的惰性续行', () => {
    const result = parse([
        '- 列表 [Workflow',
        'Distribution](https://example.invalid)',
        '',
        '> 引用 [Workflow',
        'Distribution](https://example.invalid)',
        '',
    ].join('\n'));

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), [
        '列表 Workflow Distribution',
        '引用 Workflow Distribution',
    ]);
});

test('Markdown Visible Text Module 排除列表与引用中的 fenced code', () => {
    const result = parse([
        '- Visible list',
        '    ~~~js',
        '    Workflow Distribution',
        '    ~~~',
        '',
        '> ~~~js',
        '> Workflow Distribution',
        '> ~~~',
        '> Visible quote',
        '',
    ].join('\n'));

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), ['Visible list', 'Visible quote']);
});

test('Markdown Visible Text Module 在容器结束后重新解释顶层 fence', () => {
    for (const source of [
        [
            '> ~~~js',
            '> Hidden quote',
            '~~~',
            'Hidden top level',
            '~~~',
            'Visible',
            '',
        ],
        [
            '- Visible list',
            '  ~~~js',
            '  Hidden list',
            '~~~',
            'Hidden top level',
            '~~~',
            'Visible',
            '',
        ],
    ]) {
        const result = parse(source.join('\n'));

        assert.deepEqual(result.diagnostics, []);
        assert.deepEqual(result.flows.map(flow => flow.text), source[0].startsWith('>')
            ? ['Visible']
            : ['Visible list', 'Visible']);
    }
});

test('Markdown Visible Text Module 允许未闭合 fence 隐藏到 quote 或 list 容器结尾', () => {
    for (const [source, visible] of [
        [
            ['> ~~~js', '> Hidden quote', 'Visible after quote', ''],
            ['Visible after quote'],
        ],
        [
            ['- Visible list', '  ~~~js', '  Hidden list', 'Visible after list', ''],
            ['Visible list', 'Visible after list'],
        ],
    ]) {
        const result = parse(source.join('\n'));

        assert.deepEqual(result.diagnostics, []);
        assert.deepEqual(result.flows.map(flow => flow.text), visible);
    }
});

test('Markdown Visible Text Module 排除引用中的缩进代码', () => {
    const result = parse('>     Workflow Distribution\n> Visible\n');

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), ['Visible']);
});

test('Markdown Visible Text Module 不把行首完整三反引号 code span 当作 fence', () => {
    const result = parse('```Workflow Distribution``` Visible\n');

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), ['Visible']);
});

test('Markdown Visible Text Module 在惰性续行中不把完整三反引号 code span 当作 fence', () => {
    const result = parse([
        '- 列表',
        '```Workflow Distribution``` 可见',
        '',
        '> 引用',
        '```Workflow Distribution``` 可见',
        '',
    ].join('\n'));

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), ['列表 可见', '引用 可见']);
});

test('Markdown Visible Text Module 排除跨行 HTML tag 和 attribute', () => {
    const result = parse('<div\n    class="Workflow Distribution">\nVisible\n</div>\n');

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), ['Visible']);
});

test('Markdown Visible Text Module 排除 reference definition 的续行 title', () => {
    const result = parse('Visible [label][ref]\n\n[ref]: https://example.invalid\n  "Workflow Distribution"\n');

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), ['Visible label']);
});

test('Markdown Visible Text Module 排除列表与引用中的 reference definition', () => {
    const result = parse([
        '> [quote-ref]: https://example.invalid',
        '>   "Workflow Distribution"',
        '> Visible [quote][quote-ref]',
        '',
        '- [list-ref]: https://example.invalid',
        '  "Workflow Distribution"',
        '- Visible [list][list-ref]',
        '',
    ].join('\n'));

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), ['Visible quote', 'Visible list']);
});

test('Markdown Visible Text Module 递归解释嵌套引用与列表容器', () => {
    const result = parse([
        '> - [nested-ref]: https://example.invalid',
        '>   "Workflow Distribution"',
        '> - Visible [nested][nested-ref]',
        '>   and [Workflow',
        '>   Distribution](https://example.invalid)',
        '> - ~~~js',
        '>   Workflow Distribution',
        '>   ~~~',
        '> >     Workflow Distribution',
        '> > Visible quote',
        '',
    ].join('\n'));

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), [
        'Visible nested and Workflow Distribution',
        'Visible quote',
    ]);
});

test('Markdown Visible Text Module 先排除 inline code 再解释 HTML', () => {
    const result = parse('`<!-- Workflow Distribution -->` Visible\n');

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), ['Visible']);
});

test('Markdown Visible Text Module 从单列表格只提取 cell 文字', () => {
    const result = parse('| Header |\n| --- |\n| Visible |\n');

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), ['Header', 'Visible']);
});

test('Markdown Visible Text Module 在引用容器中识别表格', () => {
    const result = parse([
        '> | Header one | Header two |',
        '> | --- | --- |',
        '> | Visible one | Visible two |',
        '',
    ].join('\n'));

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), [
        'Header one',
        'Header two',
        'Visible one',
        'Visible two',
    ]);
});

test('Markdown Visible Text Module 保留不是 HTML 或 autolink 的尖括号文字', () => {
    const result = parse('普通 < ARW Artifact > 文字.\n');

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), ['普通 < ARW Artifact > 文字.']);
});

test('Markdown Visible Text Module 只用准确 closing tag 结束 script 正文', () => {
    const result = parse('<script>\nhidden\n</scriptx>\nARW Artifact\n</script>\nVisible\n');

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), ['Visible']);
});

test('Markdown Visible Text Module 不把 HTML 隐藏正文中的 fence 当作代码块', () => {
    const result = parse('<!--\n```js\n--emphasis--\n-->\nVisible\n');

    assert.deepEqual(result.diagnostics, []);
    assert.deepEqual(result.flows.map(flow => flow.text), ['Visible']);
});
