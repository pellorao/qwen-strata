import assert from 'node:assert/strict';
import test from 'node:test';

import {analyzeDocumentLanguage} from '../../lib/common/document-language.mjs';

test('Document Language Analysis Module 按 Unicode code point 与规定权重统计正文', () => {
    assert.deepEqual(analyzeDocumentLanguage({
        flows: [{kind: 'body', text: '中文 English Русский 123 !'}],
        path: 'docs/example.md',
    }), {
        chinese: 16,
        english: 28,
        other: 56,
        path: 'docs/example.md',
    });
});

test('Document Language Analysis Module 忽略非字母并用 null 表示无有效值', () => {
    assert.deepEqual(analyzeDocumentLanguage({
        flows: [{kind: 'body', text: '123 〇 ! 😀'}],
        path: 'empty.md',
    }), {
        chinese: null,
        english: null,
        other: null,
        path: 'empty.md',
    });
});

test('Document Language Analysis Module 拒绝 heading flow 和开放输入', () => {
    assert.throws(() => analyzeDocumentLanguage({
        flows: [{kind: 'heading', text: 'Heading'}],
        path: 'docs/example.md',
    }), /body flows/u);
    assert.throws(() => analyzeDocumentLanguage({
        extra: true,
        flows: [],
        path: 'docs/example.md',
    }), /body flows/u);
});
