import assert from 'node:assert/strict';
import test from 'node:test';

import {parseTreeBlobEntries, readBatchBlobs} from '../../lib/common/git-content.mjs';

test('Git Content parses only complete NUL-delimited blob tree entries', () => {
    assert.deepEqual(parseTreeBlobEntries(Buffer.from('100644 blob 0123456789012345678901234567890123456789\tpath/file.md\0')), [{
        mode: '100644',
        objectId: '0123456789012345678901234567890123456789',
        path: 'path/file.md',
    }]);
    assert.throws(() => parseTreeBlobEntries(Buffer.from('160000 commit 0123456789012345678901234567890123456789\tmodule\0')), /unsupported blob entry/u);
});

test('Git Content reads requested blobs from one closed batch response', async () => {
    const objectId = '0123456789012345678901234567890123456789';
    const git = {
        run: async (/** @type {{argv: string[], input?: Buffer | string}} */ input) => {
            assert.deepEqual(input.argv, ['cat-file', '--batch']);
            assert.deepEqual(input.input, Buffer.from(`${objectId}\n`));
            return {code: 0, failure: null, stderr: '', stdout: Buffer.from(`${objectId} blob 4\nbody\n`)};
        },
    };
    assert.deepEqual(await readBatchBlobs({git, objectIds: [objectId]}), new Map([[objectId, Buffer.from('body')]]));
});
