import assert from 'node:assert/strict';
import test from 'node:test';

import {
    assertConfigurationConversionRules,
    convertConfiguration,
} from '../../lib/common/configuration-conversion.mjs';

const validObject = (/** @type {unknown} */ value) => value !== null && typeof value === 'object' && !Array.isArray(value)
    ? []
    : [{code: 'configuration-object-required', message: 'Configuration must be an object.'}];

const rules = {
    versions: [
        {
            conversions: [],
            fields: [
                {defaultValue: 1, path: 'configVersion', required: true},
                {path: 'name', required: true},
                {path: 'options', required: false},
                {defaultValue: true, path: 'options.enabled', required: false},
                {path: 'dynamic', required: false},
            ],
            validate: validObject,
            version: 1,
        },
        {
            conversions: [
                {convert: (/** @type {unknown} */ value) => value === 1 ? 3 : value, sourcePath: 'configVersion', targetPath: 'configVersion'},
            ],
            fields: [
                {defaultValue: 3, path: 'configVersion', required: true},
                {path: 'name', required: true},
                {path: 'options', required: false},
                {defaultValue: true, path: 'options.enabled', required: false},
                {path: 'added', required: true},
                {defaultValue: 50, path: 'added.limit', required: true},
                {path: 'dynamic', required: false},
            ],
            validate: validObject,
            version: 3,
        },
    ],
};

const copyRules = () => ({
    versions: rules.versions.map(version => ({
        ...version,
        conversions: version.conversions.map(conversion => ({...conversion})),
        fields: version.fields.map(field => ({...field})),
    })),
});

test('Configuration Conversion upgrades through ordered fields and preserves unknown subtrees', () => {
    assert.doesNotThrow(() => assertConfigurationConversionRules(rules));
    const result = convertConfiguration({
        rules,
        sourceBytes: Buffer.from('{"configVersion":1,"name":"A","options":{"extra":"keep"},"dynamic":{"inside":1},"unknown":{"x":1}}\n'),
    });

    assert.deepEqual(result, {
        status: 'succeeded',
        diagnostics: [],
        changed: true,
        sourceVersion: 1,
        targetVersion: 3,
        bytes: Buffer.from([
            '{',
            '  "configVersion": 3,',
            '  "name": "A",',
            '  "options": {',
            '    "enabled": true,',
            '    "extra": "keep"',
            '  },',
            '  "added": {',
            '    "limit": 50',
            '  },',
            '  "dynamic": {',
            '    "inside": 1',
            '  },',
            '  "unknown": {',
            '    "x": 1',
            '  }',
            '}',
            '',
        ].join('\n')),
        changes: [{
            sourceVersion: 1,
            targetVersion: 3,
            entries: [
                {kind: 'converted', sourcePath: 'configVersion', targetPath: 'configVersion'},
                {kind: 'added', path: 'added.limit'},
            ],
        }],
        unknownPaths: ['options.extra', 'unknown'],
    });
});

test('Configuration Conversion preserves exact current bytes and reports current unknown roots', () => {
    const sourceBytes = Buffer.from('{\r\n  "configVersion": 3,\r\n  "name": "A",\r\n  "added": {"limit": 7},\r\n  "unknown": true\r\n}\r\n');
    const result = convertConfiguration({rules, sourceBytes});

    assert.deepEqual(result, {
        status: 'succeeded',
        diagnostics: [],
        changed: false,
        sourceVersion: 3,
        targetVersion: 3,
        bytes: sourceBytes,
        changes: [],
        unknownPaths: ['unknown'],
    });
});

test('Configuration Conversion blocks unsupported versions, invalid JSON, and validators', () => {
    for (const [sourceBytes, code] of [
        [Buffer.from('{'), 'json-invalid'],
        [Buffer.from('{"configVersion":2}'), 'configuration-version-unsupported'],
        [Buffer.from('{"configVersion":1}'), 'configuration-required-path-missing'],
    ]) {
        const result = convertConfiguration({rules, sourceBytes});
        assert.equal(result.status, 'blocked');
        assert.deepEqual(Object.keys(result).sort(), ['diagnostics', 'status']);
        assert.equal(result.diagnostics[0].code, code);
    }
});

test('Configuration Conversion rule assertion rejects inconsistent conversion defaults', () => {
    const invalid = {
        versions: rules.versions.map(version => ({
            ...version,
            conversions: version.conversions.map(conversion => ({...conversion})),
            fields: version.fields.map(field => ({...field})),
        })),
    };
    invalid.versions[1].fields[0] = {path: 'configVersion', required: true};
    invalid.versions[1].conversions[0].convert = (/** @type {unknown} */ value) => value;
    assert.throws(() => assertConfigurationConversionRules(invalid), /defaultValue/);
});

test('Configuration Conversion rules require contiguous depth-first field subtrees', () => {
    const invalid = {
        versions: [{
            conversions: [],
            fields: [
                {defaultValue: 1, path: 'configVersion', required: true},
                {path: 'a', required: false},
                {path: 'a.x', required: false},
                {path: 'b', required: false},
                {path: 'a.y', required: false},
            ],
            validate: validObject,
            version: 1,
        }],
    };

    assert.throws(() => assertConfigurationConversionRules(invalid), /depth-first/u);
});

test('Configuration Conversion applies converted parent subtrees before descendant processing', () => {
    const parentRules = {
        versions: [
            {
                conversions: [],
                fields: [
                    {defaultValue: 1, path: 'configVersion', required: true},
                    {path: 'legacy', required: true},
                ],
                validate: validObject,
                version: 1,
            },
            {
                conversions: [
                    {convert: () => 2, sourcePath: 'configVersion', targetPath: 'configVersion'},
                    {convert: (/** @type {unknown} */ value) => ({mode: value}), sourcePath: 'legacy', targetPath: 'settings'},
                ],
                fields: [
                    {defaultValue: 2, path: 'configVersion', required: true},
                    {path: 'settings', required: true},
                    {path: 'settings.mode', required: true},
                ],
                validate: validObject,
                version: 2,
            },
        ],
    };
    assert.doesNotThrow(() => assertConfigurationConversionRules(parentRules));

    const result = convertConfiguration({
        rules: parentRules,
        sourceBytes: Buffer.from('{"configVersion":1,"legacy":"strict"}\n'),
    });

    assert.equal(result.status, 'succeeded');
    if (result.status !== 'succeeded') assert.fail('Parent conversion must succeed.');
    assert.deepEqual(JSON.parse(result.bytes.toString('utf8')), {
        configVersion: 2,
        settings: {mode: 'strict'},
    });
});

test('Configuration Conversion gives fan-out converters independent source snapshots', () => {
    const source = {nested: {count: 1}};
    const fanOutRules = {
        versions: [
            {
                conversions: [],
                fields: [
                    {defaultValue: 1, path: 'configVersion', required: true},
                    {path: 'source', required: true},
                ],
                validate: validObject,
                version: 1,
            },
            {
                conversions: [
                    {convert: () => 4, sourcePath: 'configVersion', targetPath: 'configVersion'},
                    {
                        convert: (/** @type {{nested: {count: number}}} */ value) => {
                            value.nested.count = 2;
                            return value;
                        },
                        sourcePath: 'source',
                        targetPath: 'left',
                    },
                    {
                        convert: (/** @type {{nested: {count: number}}} */ value) => value.nested.count,
                        sourcePath: 'source',
                        targetPath: 'right',
                    },
                ],
                fields: [
                    {defaultValue: 4, path: 'configVersion', required: true},
                    {path: 'left', required: true},
                    {path: 'right', required: true},
                ],
                validate: validObject,
                version: 4,
            },
        ],
    };
    assert.doesNotThrow(() => assertConfigurationConversionRules(fanOutRules));

    const result = convertConfiguration({
        rules: fanOutRules,
        sourceBytes: Buffer.from(`${JSON.stringify({configVersion: 1, source})}\n`),
    });

    assert.equal(result.status, 'succeeded');
    if (result.status !== 'succeeded') assert.fail('Fan-out conversion must succeed.');
    assert.deepEqual(JSON.parse(result.bytes.toString('utf8')), {
        configVersion: 4,
        left: {nested: {count: 2}},
        right: 1,
    });
    assert.deepEqual(source, {nested: {count: 1}});
});

test('Configuration Conversion blocks target conflicts and converter failures without a candidate', () => {
    const conflict = convertConfiguration({
        rules,
        sourceBytes: Buffer.from('{"configVersion":1,"name":"A","added":"extension"}\n'),
    });
    assert.equal(conflict.status, 'blocked');
    assert.deepEqual(Object.keys(conflict).sort(), ['diagnostics', 'status']);
    assert.equal(conflict.diagnostics[0].code, 'configuration-unknown-path-conflict');

    const converterFailureRules = copyRules();
    Reflect.set(converterFailureRules.versions[1].conversions[0], 'convert', () => {
        throw new Error('conversion failed');
    });
    const failed = convertConfiguration({
        rules: converterFailureRules,
        sourceBytes: Buffer.from('{"configVersion":1,"name":"A"}\n'),
    });
    assert.equal(failed.status, 'blocked');
    assert.deepEqual(Object.keys(failed).sort(), ['diagnostics', 'status']);
    assert.equal(failed.diagnostics[0].code, 'configuration-converter-error');
});

test('Configuration Conversion skips defaults below an absent optional parent and enforces validator diagnostics', () => {
    const optional = convertConfiguration({
        rules,
        sourceBytes: Buffer.from('{"configVersion":1,"name":"A"}\n'),
    });
    assert.equal(optional.status, 'succeeded');
    if (optional.status !== 'succeeded') assert.fail('Optional parent conversion must succeed.');
    assert.equal(Object.hasOwn(JSON.parse(optional.bytes.toString('utf8')), 'options'), false);

    const invalidValidatorRules = copyRules();
    Reflect.set(invalidValidatorRules.versions[0], 'validate', () => [{message: 'missing code'}]);
    assert.throws(
        () => convertConfiguration({
            rules: invalidValidatorRules,
            sourceBytes: Buffer.from('{"configVersion":1,"name":"A"}\n'),
        }),
        /returned invalid diagnostics/u,
    );

    const invalidPathRules = copyRules();
    Reflect.set(invalidPathRules.versions[0], 'validate', () => [{
        code: 'invalid-name',
        message: 'Name is invalid.',
        path: 'name[0]',
    }]);
    assert.throws(
        () => convertConfiguration({
            rules: invalidPathRules,
            sourceBytes: Buffer.from('{"configVersion":1,"name":"A"}\n'),
        }),
        /returned invalid diagnostics/u,
    );
});
