import assert from 'node:assert/strict';
import test from 'node:test';

import {createJiraClient} from '../../lib/application-jira/jira-client.mjs';

/** @typedef {{baseUrl: string, body?: unknown, method: 'GET' | 'POST', query?: Record<string, string>, relativeEndpoint: string}} JiraRequestInput */

test('JIRA List requests one configured candidate page and normalizes its entries', async () => {
    /** @type {JiraRequestInput[]} */
    const requests = [];
    const client = createJiraClient({
        request: async input => {
            requests.push(input);
            return {
                diagnostics: [],
                metadata: {status: 200},
                status: 'succeeded',
                value: {
                    issues: [
                        {fields: {summary: 'First\u0007issue'}, key: 'PAY-1'},
                        {fields: {summary: ' Second\n\tissue '}, key: 'PAY-2'},
                    ],
                    total: 7,
                },
            };
        },
    });

    assert.deepEqual(await client.listCandidates({
        jira: {
            baseUrl: 'https://jira.example.test/team/',
            projectKey: 'PAY',
            issueType: 'Story',
            candidateStatus: 'Backlog',
        },
        limit: 2,
    }), {
        diagnostics: [],
        entries: [
            {key: 'PAY-1', title: 'First issue'},
            {key: 'PAY-2', title: 'Second issue'},
        ],
        status: 'succeeded',
        total: 7,
    });
    assert.deepEqual(requests, [{
        baseUrl: 'https://jira.example.test/team/',
        method: 'GET',
        query: {
            fields: 'key,summary',
            jql: 'project = "PAY" AND issuetype = "Story" AND status = "Backlog" ORDER BY key ASC',
            maxResults: '2',
            startAt: '0',
        },
        relativeEndpoint: 'rest/api/2/search',
    }]);
});

test('JIRA Print obtains every comment page and returns one stable normalized value', async () => {
    /** @type {JiraRequestInput[]} */
    const requests = [];
    const client = createJiraClient({
        request: async input => {
            requests.push(input);
            if (input.relativeEndpoint.endsWith('/comment')) {
                return {
                    diagnostics: [],
                    status: 'succeeded',
                    value: {
                        comments: [{author: {displayName: 'Older', key: 'old', name: 'older'}, body: 'Old body', created: '2024-01-01', id: '1'}],
                        maxResults: 100,
                        startAt: 1,
                        total: 2,
                    },
                };
            }
            return {
                diagnostics: [],
                status: 'succeeded',
                value: {
                    fields: {
                        assignee: null,
                        attachment: [{
                            author: {displayName: 'Reporter', key: 'rep', name: 'reporter'},
                            content: 'https://jira.example.test/attachment/9',
                            created: '2024-01-03',
                            filename: 'proof.txt',
                            id: '9',
                            mimeType: 'text/plain',
                            size: 12,
                        }],
                        comment: {
                            comments: [{author: {displayName: 'Newer', key: 'new', name: 'newer'}, body: 'New body', created: '2024-01-02', id: '2'}],
                            maxResults: 1,
                            startAt: 0,
                            total: 2,
                        },
                        components: [{name: 'API'}, {name: 'Accounts'}],
                        created: '2024-01-01',
                        creator: {displayName: 'Creator', key: 'creator-key', name: 'creator'},
                        customfield_100: {tier: 'gold'},
                        description: 'Original wiki text',
                        fixVersions: [{name: '2.0'}, {name: '1.0'}],
                        issuetype: {name: 'Story'},
                        issuelinks: [{
                            id: '7',
                            outwardIssue: {fields: {status: {name: 'Open'}, summary: 'Dependency'}, key: 'PAY-9', self: 'https://jira.example.test/rest/api/2/issue/PAY-9'},
                            type: {name: 'Blocks', outward: 'blocks'},
                        }],
                        labels: ['zeta', 'alpha'],
                        priority: {name: 'High'},
                        project: {key: 'PAY', name: 'Payments'},
                        reporter: {displayName: 'Reporter', key: 'rep', name: 'reporter'},
                        status: {name: 'Backlog'},
                        summary: 'A story',
                        timespent: 0,
                        updated: '2024-01-04',
                    },
                    key: 'PAY/1',
                    names: {creator: 'Creator', customfield_100: 'Customer tier', timespent: 'Time spent'},
                    schema: {creator: {type: 'user'}, customfield_100: {type: 'any'}, timespent: {type: 'number'}},
                },
            };
        },
    });

    const result = await client.printIssue({baseUrl: 'https://jira.example.test/team/', issueKey: 'PAY/1'});
    assert.equal(result.status, 'succeeded');
    assert.deepEqual(result.value, {
        key: 'PAY/1',
        url: 'https://jira.example.test/team/browse/PAY%2F1',
        project: {key: 'PAY', name: 'Payments'},
        issueType: 'Story',
        status: 'Backlog',
        summary: 'A story',
        description: 'Original wiki text',
        priority: 'High',
        reporter: {key: 'rep', name: 'reporter', displayName: 'Reporter'},
        assignee: null,
        labels: ['alpha', 'zeta'],
        components: ['API', 'Accounts'],
        fixVersions: ['1.0', '2.0'],
        created: '2024-01-01',
        updated: '2024-01-04',
        comments: [
            {author: {key: 'old', name: 'older', displayName: 'Older'}, body: 'Old body', created: '2024-01-01'},
            {author: {key: 'new', name: 'newer', displayName: 'Newer'}, body: 'New body', created: '2024-01-02'},
        ],
        attachments: [{
            id: '9',
            filename: 'proof.txt',
            mimeType: 'text/plain',
            size: 12,
            created: '2024-01-03',
            author: {key: 'rep', name: 'reporter', displayName: 'Reporter'},
            contentUrl: 'https://jira.example.test/attachment/9',
            thumbnailUrl: null,
        }],
        links: [{
            id: '7',
            type: 'Blocks',
            direction: 'outward',
            relationship: 'blocks',
            issue: {
                key: 'PAY-9',
                url: 'https://jira.example.test/rest/api/2/issue/PAY-9',
                summary: 'Dependency',
                status: 'Open',
            },
        }],
        customFields: [{id: 'customfield_100', name: 'Customer tier', value: {tier: 'gold'}}],
        otherFields: [
            {id: 'creator', name: 'Creator', value: {key: 'creator-key', name: 'creator', displayName: 'Creator'}},
            {id: 'timespent', name: 'Time spent', value: 0},
        ],
    });
    assert.deepEqual(requests, [
        {
            baseUrl: 'https://jira.example.test/team/',
            method: 'GET',
            query: {expand: 'names,schema', fields: '*all'},
            relativeEndpoint: 'rest/api/2/issue/PAY%2F1',
        },
        {
            baseUrl: 'https://jira.example.test/team/',
            method: 'GET',
            query: {maxResults: '100', startAt: '1'},
            relativeEndpoint: 'rest/api/2/issue/PAY%2F1/comment',
        },
    ]);
});

test('JIRA Print rejects invalid comment bodies and pagination metadata without partial output', async () => {
    const cases = [
        {
            initial: {comments: [{body: null, id: '1'}], startAt: 0, total: 1},
            label: 'non-string body',
        },
        {
            fields: {comment: []},
            label: 'non-object comment collection',
        },
        {
            fields: {attachment: {}},
            label: 'non-array attachment collection',
        },
        {
            fields: {issuelinks: 'invalid'},
            label: 'non-array link collection',
        },
        {
            initial: {comments: [{body: 'body', created: null, id: '1'}], startAt: 0, total: 1},
            label: 'non-string created date',
        },
        {
            initial: {comments: [{body: 'body', id: '1'}], startAt: 1, total: 2},
            label: 'nonzero initial cursor',
        },
        {
            initial: {comments: [{body: 'body', id: '1'}], startAt: 0, total: 0},
            label: 'initial page beyond total',
        },
        {
            initial: {comments: [{body: 'first', id: '1'}], startAt: 0, total: 2},
            label: 'non-progressing next cursor',
            next: {comments: [{body: 'second', id: '2'}], startAt: 0, total: 2},
        },
        {
            initial: {comments: [{body: 'first', id: '1'}], startAt: 0, total: 2},
            label: 'empty incomplete page',
            next: {comments: [], startAt: 1, total: 2},
        },
    ];

    for (const entry of cases) {
        const client = createJiraClient({
            request: async input => ({
                diagnostics: [],
                status: /** @type {'succeeded'} */ ('succeeded'),
                value: input.relativeEndpoint.endsWith('/comment')
                    ? entry.next
                    : {fields: entry.fields ?? {comment: entry.initial}, key: 'PAY-1', names: {}, schema: {}},
            }),
        });
        const result = await client.printIssue({baseUrl: 'https://jira.example.test/', issueKey: 'PAY-1'});
        assert.equal(result.status, 'failed', entry.label);
        assert.equal(result.diagnostics[0]?.code, 'jira-response-invalid', entry.label);
    }
});
