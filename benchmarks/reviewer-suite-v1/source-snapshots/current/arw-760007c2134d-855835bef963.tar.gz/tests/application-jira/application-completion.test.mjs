import assert from 'node:assert/strict';
import test from 'node:test';

import {evaluateApplicationCompletion} from '../../lib/application-jira/application-completion.mjs';

const spec = '# Payment retry\n\nJIRA issue: [`PAY-123`](https://jira.example.test/browse/PAY-123)\n\nApplication validation issue: 05\n';

test('Application Completion distinguishes spec-only acceptance from complete validated effort', () => {
    assert.deepEqual(evaluateApplicationCompletion({issues: [], jiraBaseUrl: 'https://jira.example.test/', phase: 'accepted', applicationName: 'payments', specId: 'spec:0001', specText: spec}), {
        diagnostics: [],
        eligible: true,
        jiraKey: 'PAY-123',
        applicationName: 'payments',
        specId: 'spec:0001',
        status: 'succeeded',
    });
    assert.deepEqual(evaluateApplicationCompletion({
        issues: [
            {blockers: [], id: 'issue:0001:02', kind: 'application-source', number: '02', status: 'completed'},
            {blockers: [{number: '02'}], id: 'issue:0001:05', kind: 'implementation', number: '05', status: 'completed'},
        ],
        jiraBaseUrl: 'https://jira.example.test/',
        phase: 'completed',
        applicationName: 'payments',
        specId: 'spec:0001',
        specText: spec,
    }), {
        diagnostics: [],
        eligible: true,
        jiraKey: 'PAY-123',
        applicationName: 'payments',
        specId: 'spec:0001',
        status: 'succeeded',
    });
});

test('Application Completion returns an ineligible decision for incomplete validation', () => {
    const result = evaluateApplicationCompletion({
        issues: [
            {blockers: [], id: 'issue:0001:02', kind: 'application-source', number: '02', status: 'completed'},
            {blockers: [{number: '02'}], id: 'issue:0001:05', kind: 'implementation', number: '05', status: 'ready-for-agent'},
        ],
        jiraBaseUrl: 'https://jira.example.test/',
        phase: 'completed',
        applicationName: 'payments',
        specId: 'spec:0001',
        specText: spec,
    });
    assert.equal(result.status, 'succeeded');
    assert.equal(result.eligible, false);
});

test('Application Completion blocks malformed JIRA base URLs without throwing', () => {
    assert.deepEqual(evaluateApplicationCompletion({
        issues: [],
        jiraBaseUrl: 'not a URL',
        phase: 'accepted',
        applicationName: 'payments',
        specId: 'spec:0001',
        specText: spec,
    }), {
        diagnostics: [{code: 'application-spec-jira-metadata-invalid', message: 'Committed Application spec has invalid JIRA issue metadata.'}],
        status: 'blocked',
    });
});
