import assert from 'node:assert/strict';
import {mkdir, readFile, writeFile} from 'node:fs/promises';
import {dirname, join} from 'node:path';
import test from 'node:test';

import {createTemporaryDirectory} from '../helpers/cleanup.mjs';
import {createScopedFilesystem} from '../../lib/common/filesystem.mjs';
import {
    applyPathOwnershipPlan,
    inspectInstallation,
    planPathRegistration,
    planPathRemoval,
    writeInstallationManifest,
} from '../../lib/installation/installation-contract.mjs';
import {validateInstallationManifestRecord} from '../../lib/arw-common/installation-manifest.mjs';

/** @param {string} installationDirectory @param {unknown[]} pathOwnership */
const writeManifest = async (installationDirectory, pathOwnership) => {
    await writeFile(join(installationDirectory, 'manifest.json'), `${JSON.stringify({
        arwVersion: '0.2.0',
        managedFiles: ['arw.mjs'],
        manifestVersion: 2,
        pathOwnership,
        product: 'agent-repository-workflow',
    }, null, 2)}\n`);
};

test('Installation inspection returns fixed pathKind values without PATH ownership', async t => {
    for (const [platform, pathKind] of [
        ['win32', 'windows-user-path'],
        ['linux', 'linux-profile'],
        ['darwin', 'macos-experimental'],
    ]) {
        const root = await createTemporaryDirectory(t, `installation-contract-${platform}-`);
        const installationDirectory = join(root, 'installation');
        await mkdir(installationDirectory);

        const result = await inspectInstallation({installationDirectory, platform});

        assert.deepEqual(result, {
            diagnostics: [],
            installation: {installationDirectory, manifest: null, pathKind},
            status: 'succeeded',
        });
    }
});

test('Installation inspection validates manifest ownership against the fixed platform kind', async t => {
    const root = await createTemporaryDirectory(t, 'installation-contract-owned-');
    const installationDirectory = join(root, 'installation');
    await mkdir(installationDirectory);
    await writeManifest(installationDirectory, [{kind: 'linux-profile', profile: join(dirname(installationDirectory), '.profile')}]);

    const accepted = await inspectInstallation({installationDirectory, platform: 'linux'});
    const rejected = await inspectInstallation({installationDirectory, platform: 'win32'});

    assert.equal(accepted.status, 'succeeded');
    if (accepted.status !== 'succeeded' || accepted.installation === null) assert.fail('Owned manifest must be available.');
    assert.equal(accepted.installation.pathKind, 'linux-profile');
    assert.equal(accepted.installation.manifest?.pathOwnership[0].kind, 'linux-profile');
    assert.equal(rejected.status, 'blocked');
    assert.deepEqual(Object.keys(rejected).sort(), ['diagnostics', 'status']);
    assert.equal(rejected.diagnostics[0].code, 'installation-manifest-unsupported');
});

test('Installation inspection closes absent, unsupported, and malformed results', async t => {
    const root = await createTemporaryDirectory(t, 'installation-contract-results-');
    const missing = join(root, 'missing');
    assert.deepEqual(await inspectInstallation({installationDirectory: missing, platform: 'linux'}), {
        diagnostics: [],
        installation: null,
        status: 'succeeded',
    });

    const unsupported = await inspectInstallation({installationDirectory: missing, platform: 'freebsd'});
    assert.equal(unsupported.status, 'blocked');
    assert.deepEqual(Object.keys(unsupported).sort(), ['diagnostics', 'status']);

    const damagedDirectory = join(root, 'damaged');
    await mkdir(damagedDirectory);
    await writeFile(join(damagedDirectory, 'manifest.json'), '{');
    const damaged = await inspectInstallation({installationDirectory: damagedDirectory, platform: 'linux'});
    assert.equal(damaged.status, 'blocked');
    assert.deepEqual(Object.keys(damaged).sort(), ['diagnostics', 'status']);

    await writeFile(join(damagedDirectory, 'manifest.json'), Buffer.concat([
        Buffer.from([0xef, 0xbb, 0xbf]),
        Buffer.from(JSON.stringify({
            arwVersion: '0.2.0',
            managedFiles: ['arw.mjs'],
            manifestVersion: 2,
            pathOwnership: [],
            product: 'agent-repository-workflow',
        })),
    ]));
    const bom = await inspectInstallation({installationDirectory: damagedDirectory, platform: 'linux'});
    assert.equal(bom.status, 'blocked');
    assert.equal(bom.diagnostics[0].code, 'installation-manifest-damaged');

    await assert.rejects(
        () => inspectInstallation({installationDirectory: 'relative', platform: 'linux'}),
        /absolute installationDirectory/u,
    );
});

test('Installation manifest requires canonical managed-file order and at most one PATH ownership record', async t => {
    const root = await createTemporaryDirectory(t, 'installation-manifest-canonical-');
    const installationDirectory = join(root, 'installation');
    await mkdir(installationDirectory);
    const manifest = {
        arwVersion: '0.2.0',
        managedFiles: ['z.mjs', 'a.mjs'],
        manifestVersion: 2,
        pathOwnership: [],
        product: 'agent-repository-workflow',
    };

    assert.throws(() => validateInstallationManifestRecord({
        expectedPathKind: undefined,
        installationDirectory,
        value: manifest,
    }), /unsupported/u);
    assert.throws(() => validateInstallationManifestRecord({
        expectedPathKind: undefined,
        installationDirectory,
        value: {
            ...manifest,
            managedFiles: ['a.mjs', 'z.mjs'],
            pathOwnership: [
                {createdValue: false, entry: installationDirectory, kind: 'windows-user-path', valueKind: 'String'},
                {kind: 'linux-profile', profile: join(dirname(installationDirectory), '.profile')},
            ],
        },
    }), /unsupported/u);

    assert.doesNotThrow(() => validateInstallationManifestRecord({
        expectedPathKind: undefined,
        installationDirectory,
        value: {...manifest, managedFiles: ['lib/file name.mjs']},
    }));
    assert.throws(() => validateInstallationManifestRecord({
        expectedPathKind: undefined,
        installationDirectory,
        value: {...manifest, managedFiles: ['..']},
    }), /unsupported/u);
    for (const path of ['lib\\file.mjs', 'lib/\0file.mjs']) {
        assert.throws(() => validateInstallationManifestRecord({
            expectedPathKind: undefined,
            installationDirectory,
            value: {...manifest, managedFiles: [path]},
        }), /unsupported/u);
    }

    const scoped = await createScopedFilesystem({root});
    assert.equal(scoped.status, 'succeeded');
    if (scoped.status !== 'succeeded') assert.fail('Expected the manifest test Filesystem to open.');
    await writeInstallationManifest(
        {directory: installationDirectory, manifest: null},
        ['z.mjs', 'a.mjs'],
        [],
        {arwVersion: '0.2.0'},
        {filesystem: scoped.scopedFilesystem, installationPath: 'installation'},
    );
    assert.equal(await readFile(join(installationDirectory, 'manifest.json'), 'utf8'), [
        '{',
        '  "arwVersion": "0.2.0",',
        '  "manifestVersion": 2,',
        '  "managedFiles": [',
        '    "a.mjs",',
        '    "z.mjs"',
        '  ],',
        '  "pathOwnership": [],',
        '  "product": "agent-repository-workflow"',
        '}',
        '',
    ].join('\n'));
});

test('PATH plans are opaque, revalidate state, and report write effect', async t => {
    const root = await createTemporaryDirectory(t, 'installation-path-plan-');
    const installationDirectory = join(root, 'installation');
    let currentPath = 'C:\\Tools';
    let writes = 0;
    const installation = {
        directory: installationDirectory,
        exists: true,
        managed: false,
        manifest: null,
        pathKind: /** @type {'windows-user-path'} */ ('windows-user-path'),
    };
    const adapter = {
        notify: async () => true,
        read: async () => ({exists: /** @type {true} */ (true), kind: /** @type {'ExpandString'} */ ('ExpandString'), value: currentPath}),
        write: async (/** @type {{value: string}} */ update) => {
            writes += 1;
            currentPath = update.value;
        },
    };
    const planned = await planPathRegistration({installation, registerPath: true, windowsPath: adapter});
    assert.equal(planned.status, 'succeeded');
    if (planned.status !== 'succeeded') assert.fail('PATH plan must succeed.');
    assert.deepEqual(Object.keys(planned).sort(), ['diagnostics', 'preparedPathOwnership', 'status']);
    assert.deepEqual(Object.keys(planned.preparedPathOwnership), []);

    currentPath = 'C:\\Changed';
    const drifted = await applyPathOwnershipPlan(planned.preparedPathOwnership);
    assert.equal(drifted.status, 'blocked');
    assert.deepEqual(Object.keys(drifted).sort(), ['diagnostics', 'status']);
    assert.equal(writes, 0);

    currentPath = 'C:\\Tools';
    const stablePlan = await planPathRegistration({installation, registerPath: true, windowsPath: adapter});
    if (stablePlan.status !== 'succeeded') assert.fail('Stable PATH plan must succeed.');
    const applied = await applyPathOwnershipPlan(stablePlan.preparedPathOwnership);
    assert.equal(applied.status, 'succeeded');
    assert.equal(applied.changed, true);
    assert.equal(writes, 1);

    const failedPlan = await planPathRegistration({
        installation,
        registerPath: true,
        windowsPath: {
            notify: async () => true,
            read: async () => ({exists: true, kind: /** @type {'ExpandString'} */ ('ExpandString'), value: 'C:\\Other'}),
            write: async () => {
                throw new Error('uncertain write');
            },
        },
    });
    if (failedPlan.status !== 'succeeded') assert.fail('Failure injection plan must succeed.');
    const failed = await applyPathOwnershipPlan(failedPlan.preparedPathOwnership);
    assert.deepEqual(failed, {
        diagnostics: [{code: 'path-write-failed', message: 'uncertain write'}],
        effect: 'unknown',
        pathOwnership: [],
        stage: 'path-write',
        status: 'failed',
    });
});

test('PATH removal plans keep the empty ownership result closed and opaque', async t => {
    const root = await createTemporaryDirectory(t, 'installation-path-removal-');
    const installation = {
        directory: join(root, 'installation'),
        exists: true,
        managed: true,
        manifest: {
            arwVersion: '0.2.0',
            managedFiles: [],
            manifestVersion: /** @type {2} */ (2),
            pathOwnership: [],
            product: 'agent-repository-workflow',
        },
        pathKind: /** @type {'linux-profile'} */ ('linux-profile'),
    };
    const planned = await planPathRemoval({installation});
    assert.equal(planned.status, 'succeeded');
    if (planned.status !== 'succeeded') assert.fail('Empty removal plan must succeed.');
    assert.deepEqual(Object.keys(planned).sort(), ['diagnostics', 'preparedPathOwnership', 'status']);
    const applied = await applyPathOwnershipPlan(planned.preparedPathOwnership);
    assert.deepEqual(applied, {
        changed: false,
        diagnostics: [],
        notice: null,
        pathOwnership: [],
        status: 'succeeded',
    });
});

test('Linux profile plans use the Adapter and do not treat descendant PATH entries as equivalent', async t => {
    const root = await createTemporaryDirectory(t, 'installation-linux-profile-adapter-');
    const installationDirectory = join(root, '.agent-repository-workflow');
    const original = 'export PATH="$HOME/.agent-repository-workflow/bin:$PATH"\n';
    let content = original;
    let writes = 0;
    /** @type {NonNullable<Parameters<typeof planPathRegistration>[0]['linuxProfile']>} */
    const linuxProfile = {
        read: async () => content,
        write: async update => {
            writes += 1;
            content = update.content;
        },
    };
    const registration = await planPathRegistration({
        installation: {
            directory: installationDirectory,
            exists: true,
            managed: false,
            manifest: null,
            pathKind: 'linux-profile',
        },
        linuxProfile,
        registerPath: true,
    });
    assert.equal(registration.status, 'succeeded');
    if (registration.status !== 'succeeded') assert.fail('Linux profile registration plan must succeed.');

    const registered = await applyPathOwnershipPlan(registration.preparedPathOwnership);
    assert.equal(registered.status, 'succeeded');
    if (registered.status !== 'succeeded') assert.fail('Linux profile registration must succeed.');
    assert.equal(writes, 1);
    assert.match(content, /# >>> agent-repository-workflow PATH >>>/u);
    assert.deepEqual(registered.pathOwnership, [{kind: 'linux-profile', profile: join(root, '.profile')}]);

    const removal = await planPathRemoval({
        installation: {
            directory: installationDirectory,
            exists: true,
            managed: true,
            manifest: {
                arwVersion: '0.2.0',
                managedFiles: [],
                manifestVersion: 2,
                pathOwnership: registered.pathOwnership,
                product: 'agent-repository-workflow',
            },
            pathKind: 'linux-profile',
        },
        linuxProfile,
    });
    assert.equal(removal.status, 'succeeded');
    if (removal.status !== 'succeeded') assert.fail('Linux profile removal plan must succeed.');
    const removed = await applyPathOwnershipPlan(removal.preparedPathOwnership);
    assert.equal(removed.status, 'succeeded');
    assert.equal(writes, 2);
    assert.equal(content, original);
});

test('PATH planning rejects incomplete Installation state before observing an Adapter', async () => {
    let reads = 0;
    /** @type {NonNullable<Parameters<typeof planPathRegistration>[0]['windowsPath']>} */
    const windowsPath = {
        notify: async () => true,
        read: async () => {
            reads += 1;
            return {exists: /** @type {false} */ (false), kind: null, value: ''};
        },
        write: async () => {},
    };

    await assert.rejects(planPathRegistration(/** @type {never} */ ({
        installation: {directory: 'C:\\installation', manifest: null, pathKind: 'windows-user-path'},
        registerPath: true,
        windowsPath,
    })), TypeError);
    await assert.rejects(planPathRemoval(/** @type {never} */ ({
        installation: {
            directory: 'C:\\installation',
            exists: true,
            managed: false,
            manifest: null,
            pathKind: 'windows-user-path',
        },
        windowsPath,
    })), TypeError);
    assert.equal(reads, 0);
});
