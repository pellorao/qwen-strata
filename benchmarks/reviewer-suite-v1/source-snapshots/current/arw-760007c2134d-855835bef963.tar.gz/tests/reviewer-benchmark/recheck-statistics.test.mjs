import assert from 'node:assert/strict';
import test from 'node:test';

import {combineAvailableIndependentScores, combineIndependentScores,
    finalizeIndependentScores, scoreDivergence} from '../../lib/reviewer-benchmark/recheck-statistics.mjs';

const configuration = {model: 'gpt-example', reasoningEffort: 'low'};
const entry = (/** @type {string} */ reviewerId, /** @type {number[]} */ scores) => ({schemaVersion: 4, configuration,
    observations: [{reviewerId, repetition: 1, runtime: {durationMs: 10}}],
    roles: [{reviewerId, repetitions: scores.map((score, index) => ({repetition: index + 1,
        score, scoreSource: 'formal', diagnosticReason: /** @type {string|null} */ (null),
        mainAgentCorrectedScoringCopy: false, completedInstances: 1,
        expectedInstances: 1, deliveryErrors: []}))}]});

test('symmetric divergence treats equal zeros and one zero explicitly', () => {
    assert.equal(scoreDivergence(0, 0), 0);
    assert.equal(scoreDivergence(0, 0.1), Infinity);
    assert.equal(scoreDivergence(0.5, 0.55), scoreDivergence(0.55, 0.5));
    assert.ok(Math.abs(scoreDivergence(0.5, 0.55) - 0.1) < 1e-12);
});

test('two complete independent results compare each repetition', () => {
    const first = [entry('a', [0.4, 0.5, 0.6]), entry('b', [0.3, 0.5, 0.7])];
    const second = [entry('a', [0.43, 0.54, 0.62]), entry('b', [0.5, 0.6, 0.7])];
    const result = combineIndependentScores(first, second);
    assert.deepEqual(result.combined.map(item => item.roles[0].reviewerId), ['a']);
    assert.deepEqual(result.combined[0].roles[0].repetitions.map(item => item.score),
        [0.41500000000000004, 0.52, 0.61]);
    assert.deepEqual(result.combined[0].observations, first[0].observations);
    assert.deepEqual(result.disputes.map(item => item.reviewerId), ['b']);
    assert.deepEqual(result.disputes[0].repetitions.map(item => item.repetition), [1, 2]);
    assert.deepEqual(first[0].roles[0].repetitions.map(item => item.score), [0.4, 0.5, 0.6]);
});

test('incremental comparison includes only roles scored by both independent reviewers', () => {
    const first = [entry('a', [0.4, 0.5, 0.6]), entry('b', [0.3, 0.5, 0.7])];
    const second = [entry('a', [0.42, 0.52, 0.62]), entry('c', [0.2, 0.3, 0.4])];
    const result = combineAvailableIndependentScores(first, second);
    assert.deepEqual({commonRoles: result.commonRoles, firstOnly: result.firstOnly,
        secondOnly: result.secondOnly}, {commonRoles: 1, firstOnly: 1, secondOnly: 1});
    assert.deepEqual(result.combined.map(item => item.roles[0].reviewerId), ['a']);
    assert.deepEqual(result.combined[0].roles[0].repetitions.map(item => item.score),
        [0.41000000000000003, 0.51, 0.61]);
    assert.throws(() => combineIndependentScores(first, second), /observations differ/u);
});

test('opposing repetition differences cannot cancel when role means agree', () => {
    const result = combineIndependentScores([entry('a', [0.2, 0.8, 0.5])],
        [entry('a', [0.3, 0.7, 0.5])]);
    assert.equal(result.combined.length, 0);
    assert.deepEqual(result.disputes[0].repetitions.map(item => item.repetition), [1, 2]);
});

test('exactly ten percent difference requires Main Agent review', () => {
    const result = combineIndependentScores([entry('a', [0.5, 0.5, 0.5])],
        [entry('a', [0.55, 0.55, 0.55])]);
    assert.equal(result.combined.length, 0);
    assert.deepEqual(result.disputes[0].repetitions.map(item => item.repetition), [1, 2, 3]);
});

test('zero versus positive score remains explicit in saved disputes', () => {
    const result = combineIndependentScores([entry('a', [0, 0, 0.5])],
        [entry('a', [0, 0.2, 0.5])]);
    assert.equal(result.disputes[0].repetitions[0].repetition, 2);
    assert.equal(JSON.parse(JSON.stringify(result.disputes))[0].repetitions[0].divergence, 'Infinity');
});

test('Main Agent replaces only disputed repetition scores', () => {
    const first = [entry('a', [0.4, 0.5, 0.6]), entry('b', [0.2, 0.8, 0.5])];
    const second = [entry('a', [0.42, 0.53, 0.63]), entry('b', [0.3, 0.7, 0.5])];
    const reviewed = [entry('b', [0.25, 0.75, 0.9])];
    const final = finalizeIndependentScores(first, second, reviewed);
    assert.deepEqual(final.map(item => item.roles[0].reviewerId), ['a', 'b']);
    assert.deepEqual(final[1].roles[0].repetitions.map(item => item.score), [0.25, 0.75, 0.5]);
    assert.throws(() => finalizeIndependentScores(first, second, []), /exactly the disputed roles/u);
    assert.throws(() => finalizeIndependentScores(first, second, [entry('a', [0, 0, 0])]),
        /exactly the disputed roles/u);
});

test('different collected facts cannot be averaged as if they were the same run', () => {
    const first = [entry('a', [0.4, 0.5, 0.6])];
    const second = [entry('a', [0.42, 0.52, 0.62])];
    second[0].observations[0].runtime.durationMs = 11;
    assert.throws(() => combineIndependentScores(first, second), /observations differ/u);
    second[0].observations[0].runtime.durationMs = 10;
    second[0].roles[0].repetitions[0].diagnosticReason = 'changed';
    assert.throws(() => combineIndependentScores(first, second), /repetition facts differ/u);
});
