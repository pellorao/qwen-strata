import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import test from 'node:test';

import {launchAgentCli} from '../../arw.mjs';

test('Agent CLI Launch Module starts one direct process and returns its numeric exit code', async () => {
    /** @type {Array<{args: readonly string[], command: string, options: {cwd: string, shell: false, stdio: 'inherit', windowsHide: true}}>} */
    const calls = [];
    /** @type {NonNullable<Parameters<typeof launchAgentCli>[2]>} */
    const spawn = (command, args, options) => {
        calls.push({args, command, options});
        const child = new EventEmitter();
        queueMicrotask(() => child.emit('exit', 7));
        return child;
    };

    const result = await launchAgentCli(
        {args: ['--model', 'test-model'], command: 'agent-cli'},
        'C:\\work\\repository\\nested',
        spawn,
    );

    assert.deepEqual(result, {exitCode: 7, kind: 'exited'});
    assert.deepEqual(calls, [{
        args: ['--model', 'test-model'],
        command: 'agent-cli',
        options: {
            cwd: 'C:\\work\\repository\\nested',
            shell: false,
            stdio: 'inherit',
            windowsHide: true,
        },
    }]);
});

test('Agent CLI Launch Module classifies every expected process failure', async () => {
    /** @type {Array<{expected: {exitCode: number, kind: 'exited'} | {kind: 'failed', reason: 'missing-exit-code' | 'spawn-failed'}, spawn: NonNullable<Parameters<typeof launchAgentCli>[2]>}>} */
    const variants = [
        {
            expected: {kind: 'failed', reason: 'spawn-failed'},
            spawn: () => {
                throw new Error('missing executable');
            },
        },
        {
            expected: {kind: 'failed', reason: 'spawn-failed'},
            spawn: () => {
                const child = new EventEmitter();
                queueMicrotask(() => child.emit('error', new Error('missing executable')));
                return child;
            },
        },
        {
            expected: {kind: 'failed', reason: 'missing-exit-code'},
            spawn: () => {
                const child = new EventEmitter();
                queueMicrotask(() => child.emit('exit', null));
                return child;
            },
        },
        {
            expected: {kind: 'failed', reason: 'missing-exit-code'},
            spawn: () => {
                const child = new EventEmitter();
                queueMicrotask(() => child.emit('exit', -1));
                return child;
            },
        },
    ];

    for (const variant of variants) {
        assert.deepEqual(
            await launchAgentCli({args: [], command: 'agent-cli'}, process.cwd(), variant.spawn),
            variant.expected,
        );
    }
});
