import assert from 'node:assert/strict';
import test from 'node:test';

import {renderLanguageCompositionTable} from '../../lib/arw-common/language-composition-presentation.mjs';

test('Language Composition presentation 输出稳定紧凑表格', () => {
    assert.equal(renderLanguageCompositionTable([
        {chinese: 75, english: 25, other: 0, path: 'a.md'},
        {chinese: null, english: null, other: null, path: 'docs/empty.md'},
    ]), [
        'Document       Chinese  English  Other',
        '-------------  -------  -------  -----',
        'a.md           75.0%    25.0%    0.0%',
        'docs/empty.md  -        -        -',
    ].join('\n'));
});
