import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {readFile, writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import test from 'node:test';

import {createTemporaryDirectory} from '../helpers/cleanup.mjs';
import {launchConfiguredEditor} from '../../lib/arw-common/editor-process.mjs';

test('ordinary and waiting editors share the Windows process Adapter', async () => {
    /** @type {Array<{args: readonly string[], command: string, options: {env?: NodeJS.ProcessEnv, stdio: 'ignore' | 'inherit', windowsHide: boolean}}>} */
    const calls = [];
    /** @type {NonNullable<Parameters<typeof launchConfiguredEditor>[0]['spawn']>} */
    const spawn = (command, args, options) => {
        calls.push({args, command, options});
        const child = new EventEmitter();
        queueMicrotask(() => child.emit('exit', 0, null));
        return child;
    };
    const editor = {args: ['{file}'], command: 'configured-editor'};

    await launchConfiguredEditor({editor, filePath: 'ordinary.md', platform: 'win32', spawn, wait: false});
    await launchConfiguredEditor({editor, filePath: 'review.md', platform: 'win32', spawn, wait: true});

    assert.equal(calls.length, 2);
    const first = calls[0];
    const second = calls[1];
    if (first === undefined || second === undefined) assert.fail('Both editor launches must be recorded.');
    assert.equal(first.command, 'powershell.exe');
    assert.equal(second.command, 'powershell.exe');
    assert.deepEqual(second.args, first.args);
    assert.equal(first.options.windowsHide, true);
    assert.equal(second.options.windowsHide, true);
});

test('waiting editor executes a real Windows cmd command through the shared process Adapter', {
    skip: process.platform !== 'win32',
}, async t => {
    const directory = await createTemporaryDirectory(t, 'arw-editor-process-');
    const commandPath = join(directory, 'review editor.cmd');
    const reviewPath = join(directory, 'review result.txt');
    await writeFile(commandPath, '@echo off\r\n> "%~1" echo reviewed\r\n', 'utf8');

    await launchConfiguredEditor({
        editor: {args: ['{file}'], command: commandPath},
        filePath: reviewPath,
        platform: 'win32',
        wait: true,
    });

    assert.equal(await readFile(reviewPath, 'utf8'), 'reviewed\r\n');
});
